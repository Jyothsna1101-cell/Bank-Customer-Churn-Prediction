$binDir = "C:\Program Files\Microsoft Power BI Desktop\bin"
[System.AppDomain]::CurrentDomain.add_AssemblyResolve({
    param($sender, $args)
    $assemblyName = $args.Name.Split(',')[0]
    $assemblyPath = Join-Path $binDir "$assemblyName.dll"
    if (Test-Path $assemblyPath) {
        return [System.Reflection.Assembly]::LoadFrom($assemblyPath)
    }
    return $null
})

$adomdPath = Join-Path $binDir "Microsoft.PowerBI.AdomdClient.dll"
[System.Reflection.Assembly]::LoadFrom($adomdPath) | Out-Null
Write-Host "Successfully loaded AdomdClient assembly with auto-resolver!"

# Get active port
$pbiConns = Get-NetTCPConnection -State Listen | Where-Object {
    $proc = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
    $proc.ProcessName -eq "msmdsrv"
}
$port = $pbiConns[0].LocalPort
Write-Host "Connecting to active msmdsrv port: $port"

$connStr = "Data Source=localhost:$port;"
$conn = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection($connStr)

try {
    $conn.Open()
    Write-Host "SUCCESS: Connected to live Power BI Desktop Tabular Model!"

    # Query tables
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT [Name] FROM `$SYSTEM.TMSCHEMA_TABLES"
    $adapter = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdDataAdapter($cmd)
    $dtTables = New-Object System.Data.DataTable
    $adapter.Fill($dtTables) | Out-Null
    Write-Host "`nTABLES IN ACTIVE DATA MODEL:"
    $dtTables | Format-Table -AutoSize

    # Query columns
    $cmd.CommandText = "SELECT [TableID], [Name], [ExplicitDataType], [SourceColumn] FROM `$SYSTEM.TMSCHEMA_COLUMNS"
    $dtCols = New-Object System.Data.DataTable
    $adapter.Fill($dtCols) | Out-Null
    Write-Host "Total columns defined: $($dtCols.Rows.Count)"

    # Query measures
    $cmd.CommandText = "SELECT [Name], [Expression] FROM `$SYSTEM.TMSCHEMA_MEASURES"
    $dtMeasures = New-Object System.Data.DataTable
    $adapter.Fill($dtMeasures) | Out-Null
    Write-Host "`nMEASURES IN ACTIVE DATA MODEL ($($dtMeasures.Rows.Count)):"
    $dtMeasures | Format-Table -AutoSize

    # Query relationships
    $cmd.CommandText = "SELECT [FromTableID], [FromColumnID], [ToTableID], [ToColumnID] FROM `$SYSTEM.TMSCHEMA_RELATIONSHIPS"
    $dtRel = New-Object System.Data.DataTable
    $adapter.Fill($dtRel) | Out-Null
    Write-Host "`nRELATIONSHIPS IN MODEL: $($dtRel.Rows.Count)"
    $dtRel | Format-Table -AutoSize

    $conn.Close()
} catch {
    Write-Host "Connection error:" $_.Exception.ToString()
}
