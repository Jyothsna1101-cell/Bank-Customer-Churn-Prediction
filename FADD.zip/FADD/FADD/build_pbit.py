"""
Power BI Model & Template Generator with All 6 Tables, Relationships & DAX Measures.
Generates:
1. model.bim (in Bank_Customer_Churn_Dashboard.Dataset and Bank_Customer_Churn_Dashboard.SemanticModel)
2. Bank_Customer_Churn_Dashboard.pbit
3. Bank_Customer_Churn_Dashboard.pbip
"""

import os
import json
import zipfile

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
DASHBOARD_DIR = os.path.join(PROJECT_ROOT, "PowerBI_Dashboard")

CSV_CUSTOMERS = os.path.join(DASHBOARD_DIR, "Customers_Cleaned.csv").replace("\\", "/")
CSV_PREDICTIONS = os.path.join(DASHBOARD_DIR, "Customer_Churn_Predictions.csv").replace("\\", "/")
CSV_EVALUATION = os.path.join(DASHBOARD_DIR, "Model_Evaluation.csv").replace("\\", "/")
CSV_IMPORTANCE = os.path.join(DASHBOARD_DIR, "Feature_Importance.csv").replace("\\", "/")
CSV_CONFUSION = os.path.join(DASHBOARD_DIR, "Confusion_Matrix_Data.csv").replace("\\", "/")
CSV_ROC = os.path.join(DASHBOARD_DIR, "ROC_Curve_Data.csv").replace("\\", "/")


def build_complete_schema():
    """Builds complete TMSL Tabular DataModelSchema JSON with all 6 tables."""
    return {
        "name": "Bank_Customer_Churn_Model",
        "compatibilityLevel": 1550,
        "model": {
            "culture": "en-US",
            "dataAccessOptions": {
                "legacyRedirects": True,
                "fastCombine": True
            },
            "defaultPowerBIDataSourceVersion": "powerBI_V3",
            "sourceQueryCulture": "en-US",
            "tables": [
                {
                    "name": "Customers_Cleaned",
                    "columns": [
                        {"name": "CustomerId", "dataType": "int64", "sourceColumn": "CustomerId", "summarizeBy": "none"},
                        {"name": "CreditScore", "dataType": "int64", "sourceColumn": "CreditScore", "summarizeBy": "average"},
                        {"name": "Geography", "dataType": "string", "sourceColumn": "Geography"},
                        {"name": "Gender", "dataType": "string", "sourceColumn": "Gender"},
                        {"name": "Age", "dataType": "int64", "sourceColumn": "Age", "summarizeBy": "average"},
                        {"name": "Tenure", "dataType": "int64", "sourceColumn": "Tenure", "summarizeBy": "average"},
                        {"name": "Balance", "dataType": "decimal", "sourceColumn": "Balance", "formatString": "\\$#,0.00;(\\$#,0.00);\\$#,0.00", "summarizeBy": "sum"},
                        {"name": "NumOfProducts", "dataType": "int64", "sourceColumn": "NumOfProducts", "summarizeBy": "none"},
                        {"name": "HasCrCard", "dataType": "int64", "sourceColumn": "HasCrCard", "summarizeBy": "none"},
                        {"name": "IsActiveMember", "dataType": "int64", "sourceColumn": "IsActiveMember", "summarizeBy": "none"},
                        {"name": "EstimatedSalary", "dataType": "decimal", "sourceColumn": "EstimatedSalary", "formatString": "\\$#,0.00", "summarizeBy": "average"},
                        {"name": "Exited", "dataType": "int64", "sourceColumn": "Exited", "summarizeBy": "none"},
                        {"name": "Exited_Label", "dataType": "string", "sourceColumn": "Exited_Label"},
                        {"name": "IsActiveMember_Label", "dataType": "string", "sourceColumn": "IsActiveMember_Label"},
                        {"name": "HasCrCard_Label", "dataType": "string", "sourceColumn": "HasCrCard_Label"},
                        {"name": "AgeGroup", "dataType": "string", "sourceColumn": "AgeGroup"},
                        {"name": "CreditScoreTier", "dataType": "string", "sourceColumn": "CreditScoreTier"},
                        {"name": "BalanceTier", "dataType": "string", "sourceColumn": "BalanceTier"},
                        {"name": "SalaryTier", "dataType": "string", "sourceColumn": "SalaryTier"}
                    ],
                    "partitions": [
                        {
                            "name": "Customers_Cleaned_Partition",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    f'let Source = Csv.Document(File.Contents("{CSV_CUSTOMERS}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
                                    '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
                                    '#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"CustomerId", Int64.Type}, {"CreditScore", Int64.Type}, {"Geography", type text}, {"Gender", type text}, {"Age", Int64.Type}, {"Tenure", Int64.Type}, {"Balance", Currency.Type}, {"NumOfProducts", Int64.Type}, {"HasCrCard", Int64.Type}, {"IsActiveMember", Int64.Type}, {"EstimatedSalary", Currency.Type}, {"Exited", Int64.Type}})',
                                    'in #"Changed Type"'
                                ]
                            }
                        }
                    ],
                    "measures": [
                        {"name": "Total Customers", "expression": "DISTINCTCOUNT(Customers_Cleaned[CustomerId])", "formatString": "#,##0"},
                        {"name": "Churned Customers", "expression": 'CALCULATE([Total Customers], Customers_Cleaned[Exited] = 1)', "formatString": "#,##0"},
                        {"name": "Retained Customers", "expression": 'CALCULATE([Total Customers], Customers_Cleaned[Exited] = 0)', "formatString": "#,##0"},
                        {"name": "Churn Rate", "expression": "DIVIDE([Churned Customers], [Total Customers], 0)", "formatString": "0.00%"},
                        {"name": "Retention Rate", "expression": "1 - [Churn Rate]", "formatString": "0.00%"},
                        {"name": "Average Age", "expression": "AVERAGE(Customers_Cleaned[Age])", "formatString": "0.0"},
                        {"name": "Average Credit Score", "expression": "AVERAGE(Customers_Cleaned[CreditScore])", "formatString": "0"},
                        {"name": "Average Balance", "expression": "AVERAGE(Customers_Cleaned[Balance])", "formatString": "\\$#,##0"},
                        {"name": "Total Deposit Balance", "expression": "SUM(Customers_Cleaned[Balance])", "formatString": "\\$#,##0"},
                        {"name": "Total Balance at Risk", "expression": 'CALCULATE([Total Deposit Balance], Customers_Cleaned[Exited] = 1)', "formatString": "\\$#,##0"},
                        {"name": "Churned Balance at Risk", "expression": 'CALCULATE([Total Deposit Balance], Customers_Cleaned[Exited] = 1)', "formatString": "\\$#,##0"},
                        {"name": "Retained Balance", "expression": 'CALCULATE([Total Deposit Balance], Customers_Cleaned[Exited] = 0)', "formatString": "\\$#,##0"},
                        {"name": "Active Members", "expression": 'CALCULATE([Total Customers], Customers_Cleaned[IsActiveMember] = 1)', "formatString": "#,##0"},
                        {"name": "Inactive Members", "expression": 'CALCULATE([Total Customers], Customers_Cleaned[IsActiveMember] = 0)', "formatString": "#,##0"},
                        {"name": "Active Member Churn Rate", "expression": 'DIVIDE(CALCULATE([Churned Customers], Customers_Cleaned[IsActiveMember] = 1), [Active Members], 0)', "formatString": "0.00%"},
                        {"name": "Inactive Member Churn Rate", "expression": 'DIVIDE(CALCULATE([Churned Customers], Customers_Cleaned[IsActiveMember] = 0), [Inactive Members], 0)', "formatString": "0.00%"},
                        {"name": "Credit Card Holders", "expression": 'CALCULATE([Total Customers], Customers_Cleaned[HasCrCard] = 1)', "formatString": "#,##0"},
                        {"name": "Average Salary", "expression": "AVERAGE(Customers_Cleaned[EstimatedSalary])", "formatString": "\\$#,##0"}
                    ]
                },
                {
                    "name": "Customer_Churn_Predictions",
                    "columns": [
                        {"name": "CustomerId", "dataType": "int64", "sourceColumn": "CustomerId", "summarizeBy": "none"},
                        {"name": "Surname", "dataType": "string", "sourceColumn": "Surname"},
                        {"name": "CreditScore", "dataType": "int64", "sourceColumn": "CreditScore"},
                        {"name": "Geography", "dataType": "string", "sourceColumn": "Geography"},
                        {"name": "Gender", "dataType": "string", "sourceColumn": "Gender"},
                        {"name": "Age", "dataType": "int64", "sourceColumn": "Age"},
                        {"name": "Tenure", "dataType": "int64", "sourceColumn": "Tenure"},
                        {"name": "Balance", "dataType": "decimal", "sourceColumn": "Balance", "formatString": "\\$#,0.00"},
                        {"name": "NumOfProducts", "dataType": "int64", "sourceColumn": "NumOfProducts"},
                        {"name": "HasCrCard", "dataType": "int64", "sourceColumn": "HasCrCard"},
                        {"name": "IsActiveMember", "dataType": "int64", "sourceColumn": "IsActiveMember"},
                        {"name": "EstimatedSalary", "dataType": "decimal", "sourceColumn": "EstimatedSalary", "formatString": "\\$#,0.00"},
                        {"name": "Exited", "dataType": "int64", "sourceColumn": "Exited"},
                        {"name": "Churn_Probability", "dataType": "decimal", "sourceColumn": "Churn_Probability", "formatString": "0.00\\%"},
                        {"name": "Churn_Probability_Decimal", "dataType": "decimal", "sourceColumn": "Churn_Probability_Decimal", "formatString": "0.00%"},
                        {"name": "Predicted_Churn", "dataType": "int64", "sourceColumn": "Predicted_Churn"},
                        {"name": "Predicted_Churn_Label", "dataType": "string", "sourceColumn": "Predicted_Churn_Label"},
                        {"name": "Risk_Category", "dataType": "string", "sourceColumn": "Risk_Category"},
                        {"name": "Risk_Sort_Order", "dataType": "int64", "sourceColumn": "Risk_Sort_Order"},
                        {"name": "Recommended_Action", "dataType": "string", "sourceColumn": "Recommended_Action"},
                        {"name": "Risk_Rank", "dataType": "int64", "sourceColumn": "Risk_Rank"}
                    ],
                    "partitions": [
                        {
                            "name": "Predictions_Partition",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    f'let Source = Csv.Document(File.Contents("{CSV_PREDICTIONS}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
                                    '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
                                    '#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"CustomerId", Int64.Type}, {"CreditScore", Int64.Type}, {"Balance", Currency.Type}, {"EstimatedSalary", Currency.Type}, {"Churn_Probability", type number}, {"Churn_Probability_Decimal", type number}, {"Predicted_Churn", Int64.Type}, {"Risk_Sort_Order", Int64.Type}, {"Risk_Rank", Int64.Type}})',
                                    'in #"Changed Type"'
                                ]
                            }
                        }
                    ],
                    "measures": [
                        {"name": "High-Risk Customers", "expression": 'CALCULATE(DISTINCTCOUNT(Customer_Churn_Predictions[CustomerId]), Customer_Churn_Predictions[Risk_Category] = "High Risk")', "formatString": "#,##0"},
                        {"name": "High-Risk Percentage", "expression": "DIVIDE([High-Risk Customers], [Total Customers], 0)", "formatString": "0.00%"},
                        {"name": "High-Risk Share", "expression": "DIVIDE([High-Risk Customers], [Total Customers], 0)", "formatString": "0.00%"},
                        {"name": "Medium-Risk Customers", "expression": 'CALCULATE(DISTINCTCOUNT(Customer_Churn_Predictions[CustomerId]), Customer_Churn_Predictions[Risk_Category] = "Medium Risk")', "formatString": "#,##0"},
                        {"name": "Low-Risk Customers", "expression": 'CALCULATE(DISTINCTCOUNT(Customer_Churn_Predictions[CustomerId]), Customer_Churn_Predictions[Risk_Category] = "Low Risk")', "formatString": "#,##0"},
                        {"name": "High-Risk Balance at Stake", "expression": 'CALCULATE(SUM(Customer_Churn_Predictions[Balance]), Customer_Churn_Predictions[Risk_Category] = "High Risk")', "formatString": "\\$#,##0"},
                        {"name": "Average Predicted Churn Probability", "expression": "AVERAGE(Customer_Churn_Predictions[Churn_Probability_Decimal])", "formatString": "0.00%"},
                        {"name": "Predicted Churners", "expression": "CALCULATE(DISTINCTCOUNT(Customer_Churn_Predictions[CustomerId]), Customer_Churn_Predictions[Predicted_Churn] = 1)", "formatString": "#,##0"},
                        {"name": "Predicted Churn Rate", "expression": "DIVIDE([Predicted Churners], [Total Customers], 0)", "formatString": "0.00%"}
                    ]
                },
                {
                    "name": "Model_Evaluation",
                    "columns": [
                        {"name": "Model_Name", "dataType": "string", "sourceColumn": "Model_Name"},
                        {"name": "Algorithm_Family", "dataType": "string", "sourceColumn": "Algorithm_Family"},
                        {"name": "Accuracy", "dataType": "decimal", "sourceColumn": "Accuracy", "formatString": "0.00\\%"},
                        {"name": "Precision", "dataType": "decimal", "sourceColumn": "Precision", "formatString": "0.00\\%"},
                        {"name": "Recall", "dataType": "decimal", "sourceColumn": "Recall", "formatString": "0.00\\%"},
                        {"name": "F1_Score", "dataType": "decimal", "sourceColumn": "F1_Score", "formatString": "0.00\\%"},
                        {"name": "ROC_AUC", "dataType": "decimal", "sourceColumn": "ROC_AUC", "formatString": "0.0000"},
                        {"name": "CV_AUC_Mean", "dataType": "decimal", "sourceColumn": "CV_AUC_Mean", "formatString": "0.0000"},
                        {"name": "CV_AUC_Std", "dataType": "decimal", "sourceColumn": "CV_AUC_Std", "formatString": "0.0000"},
                        {"name": "True_Negatives", "dataType": "int64", "sourceColumn": "True_Negatives"},
                        {"name": "False_Positives", "dataType": "int64", "sourceColumn": "False_Positives"},
                        {"name": "False_Negatives", "dataType": "int64", "sourceColumn": "False_Negatives"},
                        {"name": "True_Positives", "dataType": "int64", "sourceColumn": "True_Positives"},
                        {"name": "Is_Champion", "dataType": "string", "sourceColumn": "Is_Champion"}
                    ],
                    "partitions": [
                        {
                            "name": "Evaluation_Partition",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    f'let Source = Csv.Document(File.Contents("{CSV_EVALUATION}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
                                    '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
                                    '#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Accuracy", type number}, {"Precision", type number}, {"Recall", type number}, {"F1_Score", type number}, {"ROC_AUC", type number}, {"True_Negatives", Int64.Type}, {"False_Positives", Int64.Type}, {"False_Negatives", Int64.Type}, {"True_Positives", Int64.Type}})',
                                    'in #"Changed Type"'
                                ]
                            }
                        }
                    ],
                    "measures": [
                        {"name": "Champion Model Name", "expression": 'CALCULATE(SELECTEDVALUE(Model_Evaluation[Model_Name], "Random Forest"), Model_Evaluation[Is_Champion] = "Yes")'},
                        {"name": "Champion Model Accuracy", "expression": 'CALCULATE(MAX(Model_Evaluation[Accuracy]), Model_Evaluation[Is_Champion] = "Yes") / 100', "formatString": "0.00%"},
                        {"name": "Champion Model Recall", "expression": 'CALCULATE(MAX(Model_Evaluation[Recall]), Model_Evaluation[Is_Champion] = "Yes") / 100', "formatString": "0.00%"},
                        {"name": "Champion Model Precision", "expression": 'CALCULATE(MAX(Model_Evaluation[Precision]), Model_Evaluation[Is_Champion] = "Yes") / 100', "formatString": "0.00%"},
                        {"name": "Champion Model F1-Score", "expression": 'CALCULATE(MAX(Model_Evaluation[F1_Score]), Model_Evaluation[Is_Champion] = "Yes") / 100', "formatString": "0.00%"},
                        {"name": "Champion Model ROC-AUC", "expression": 'CALCULATE(MAX(Model_Evaluation[ROC_AUC]), Model_Evaluation[Is_Champion] = "Yes")', "formatString": "0.0000"}
                    ]
                },
                {
                    "name": "Feature_Importance",
                    "columns": [
                        {"name": "Feature", "dataType": "string", "sourceColumn": "Feature"},
                        {"name": "Feature_Category", "dataType": "string", "sourceColumn": "Feature_Category"},
                        {"name": "Random_Forest_Importance", "dataType": "decimal", "sourceColumn": "Random_Forest_Importance", "formatString": "0.0000"},
                        {"name": "Random_Forest_Pct", "dataType": "decimal", "sourceColumn": "Random_Forest_Pct", "formatString": "0.00\\%"},
                        {"name": "Gradient_Boosting_Importance", "dataType": "decimal", "sourceColumn": "Gradient_Boosting_Importance", "formatString": "0.0000"},
                        {"name": "Gradient_Boosting_Pct", "dataType": "decimal", "sourceColumn": "Gradient_Boosting_Pct", "formatString": "0.00\\%"},
                        {"name": "Logistic_Regression_Coef", "dataType": "decimal", "sourceColumn": "Logistic_Regression_Coef", "formatString": "0.0000"},
                        {"name": "Logistic_Regression_Odds_Ratio", "dataType": "decimal", "sourceColumn": "Logistic_Regression_Odds_Ratio", "formatString": "0.000"},
                        {"name": "Predictive_Direction", "dataType": "string", "sourceColumn": "Predictive_Direction"},
                        {"name": "Rank", "dataType": "int64", "sourceColumn": "Rank"}
                    ],
                    "partitions": [
                        {
                            "name": "Feature_Importance_Partition",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    f'let Source = Csv.Document(File.Contents("{CSV_IMPORTANCE}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
                                    '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
                                    '#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Random_Forest_Importance", type number}, {"Random_Forest_Pct", type number}, {"Gradient_Boosting_Importance", type number}, {"Gradient_Boosting_Pct", type number}, {"Logistic_Regression_Coef", type number}, {"Logistic_Regression_Odds_Ratio", type number}, {"Rank", Int64.Type}})',
                                    'in #"Changed Type"'
                                ]
                            }
                        }
                    ]
                },
                {
                    "name": "Confusion_Matrix_Data",
                    "columns": [
                        {"name": "Model_Name", "dataType": "string", "sourceColumn": "Model_Name"},
                        {"name": "Actual_Class", "dataType": "string", "sourceColumn": "Actual_Class"},
                        {"name": "Predicted_Class", "dataType": "string", "sourceColumn": "Predicted_Class"},
                        {"name": "Count", "dataType": "int64", "sourceColumn": "Count", "formatString": "#,##0"},
                        {"name": "Type", "dataType": "string", "sourceColumn": "Type"}
                    ],
                    "partitions": [
                        {
                            "name": "Confusion_Matrix_Partition",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    f'let Source = Csv.Document(File.Contents("{CSV_CONFUSION}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
                                    '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
                                    '#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"Count", Int64.Type}})',
                                    'in #"Changed Type"'
                                ]
                            }
                        }
                    ]
                },
                {
                    "name": "ROC_Curve_Data",
                    "columns": [
                        {"name": "Model_Name", "dataType": "string", "sourceColumn": "Model_Name"},
                        {"name": "False_Positive_Rate", "dataType": "decimal", "sourceColumn": "False_Positive_Rate", "formatString": "0.0000"},
                        {"name": "True_Positive_Rate", "dataType": "decimal", "sourceColumn": "True_Positive_Rate", "formatString": "0.0000"},
                        {"name": "Threshold", "dataType": "decimal", "sourceColumn": "Threshold", "formatString": "0.0000"}
                    ],
                    "partitions": [
                        {
                            "name": "ROC_Curve_Partition",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    f'let Source = Csv.Document(File.Contents("{CSV_ROC}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
                                    '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
                                    '#"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"False_Positive_Rate", type number}, {"True_Positive_Rate", type number}, {"Threshold", type number}})',
                                    'in #"Changed Type"'
                                ]
                            }
                        }
                    ]
                }
            ],
            "relationships": [
                {
                    "name": "Rel_Predictions_Customers",
                    "fromTable": "Customer_Churn_Predictions",
                    "fromColumn": "CustomerId",
                    "toTable": "Customers_Cleaned",
                    "toColumn": "CustomerId"
                }
            ]
        }
    }


def update_all_artifacts():
    """Generates and syncs .pbip, .pbit, and semantic model folders."""
    schema = build_complete_schema()
    schema_json = json.dumps(schema, indent=2)

    # 1. Update Dataset and SemanticModel model.bim
    dataset_dir = os.path.join(DASHBOARD_DIR, "Bank_Customer_Churn_Dashboard.Dataset")
    semantic_dir = os.path.join(DASHBOARD_DIR, "Bank_Customer_Churn_Dashboard.SemanticModel")
    os.makedirs(dataset_dir, exist_ok=True)
    os.makedirs(semantic_dir, exist_ok=True)

    with open(os.path.join(dataset_dir, "model.bim"), "w", encoding="utf-8") as f:
        f.write(schema_json)
    with open(os.path.join(dataset_dir, "definition.pbidataset"), "w", encoding="utf-8") as f:
        json.dump({"version": "1.0"}, f, indent=2)

    with open(os.path.join(semantic_dir, "model.bim"), "w", encoding="utf-8") as f:
        f.write(schema_json)
    with open(os.path.join(semantic_dir, "definition.pbism"), "w", encoding="utf-8") as f:
        json.dump({"version": "1.0"}, f, indent=2)

    # 2. Update .pbit
    pbit_filepath = os.path.join(DASHBOARD_DIR, "Bank_Customer_Churn_Dashboard.pbit")
    content_types_xml = (
        '<?xml version="1.0" encoding="utf-8"?>\r\n'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\r\n'
        '  <Default Extension="json" ContentType="" />\r\n'
        '  <Override PartName="/Version" ContentType="" />\r\n'
        '  <Override PartName="/Settings" ContentType="" />\r\n'
        '  <Override PartName="/DataModelSchema" ContentType="" />\r\n'
        '  <Override PartName="/Report/Layout" ContentType="" />\r\n'
        '</Types>'
    )
    with zipfile.ZipFile(pbit_filepath, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types_xml.encode('utf-8'))
        zf.writestr("Version", "1.28".encode('utf-16le'))
        zf.writestr("Settings", "{}".encode('utf-16le'))
        zf.writestr("DataModelSchema", schema_json.encode('utf-16le'))
        layout_dict = {
            "id": 0,
            "theme": "ExecutiveNavy",
            "sections": [
                {"id": 0, "name": "ReportSection1", "displayName": "1. Executive Overview", "ordinal": 0, "visualContainers": []},
                {"id": 1, "name": "ReportSection2", "displayName": "2. Customer Demographics & Financial", "ordinal": 1, "visualContainers": []},
                {"id": 2, "name": "ReportSection3", "displayName": "3. Customer Behavioral Analysis", "ordinal": 2, "visualContainers": []},
                {"id": 3, "name": "ReportSection4", "displayName": "4. ML Model Performance", "ordinal": 3, "visualContainers": []},
                {"id": 4, "name": "ReportSection5", "displayName": "5. Customer Churn Risk Analysis", "ordinal": 4, "visualContainers": []}
            ]
        }
        zf.writestr("Report/Layout", json.dumps(layout_dict, indent=2).encode('utf-16le'))

    print("All Power BI artifacts updated with all 6 tables, relationships, and DAX measures!")


if __name__ == "__main__":
    update_all_artifacts()
