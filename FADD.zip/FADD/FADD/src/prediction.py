"""
Prediction and Inference Engine for Bank Customer Churn System.
Supports single-customer interactive scoring, personalized retention recommendations,
and high-throughput bulk CSV batch prediction with validation.
"""

import os
import sys
import json
from typing import Dict, Any, Tuple, List, Union
import numpy as np
import pandas as pd
import joblib

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.data_preprocessing import (
    standardize_columns, NUMERICAL_FEATURES, CATEGORICAL_FEATURES, IRRELEVANT_COLUMNS
)

MODEL_FILES = {
    'Random Forest (Recommended Champion)': 'random_forest.pkl',
    'Gradient Boosting (High Precision)': 'gradient_boosting.pkl',
    'Decision Tree (High Recall)': 'decision_tree.pkl',
    'Logistic Regression (Linear Baseline)': 'logistic_regression.pkl'
}


def load_model_pipeline(model_choice: str = 'Random Forest (Recommended Champion)', models_dir: str = "models"):
    """Loads selected model pipeline from disk."""
    filename = MODEL_FILES.get(model_choice, 'best_model.pkl')
    path = os.path.join(models_dir, filename)
    if not os.path.exists(path):
        # Fallback to best_model.pkl
        path = os.path.join(models_dir, 'best_model.pkl')
    return joblib.load(path)


def categorize_risk(probability: float) -> Tuple[str, str, str]:
    """
    Categorizes churn probability into risk tiers:
    - Low Risk: < 35% (Green)
    - Medium Risk: 35% - 64.9% (Amber)
    - High Risk: >= 65% (Red)
    """
    if probability >= 0.65:
        return "High Risk", "high", "#EF4444"
    elif probability >= 0.35:
        return "Medium Risk", "medium", "#F59E0B"
    else:
        return "Low Risk", "low", "#10B981"


def generate_retention_playbook(customer_data: Dict[str, Any], probability: float) -> List[Dict[str, str]]:
    """
    Synthesizes tailored, actionable customer retention recommendations
    based on the customer's specific risk level and attributes.
    """
    recommendations = []
    
    age = customer_data.get('Age', 35)
    balance = customer_data.get('Balance', 0)
    products = customer_data.get('NumOfProducts', 1)
    is_active = customer_data.get('IsActiveMember', 1)
    country = customer_data.get('Geography', 'France')
    has_card = customer_data.get('HasCrCard', 1)
    
    # 1. Inactivity Intervention
    if is_active == 0:
        recommendations.append({
            "trigger": "Customer Inactivity Detected",
            "action": "Immediate Re-Engagement Campaign",
            "details": "Initiate an automated outreach offering zero-fee transfers, personalized savings goals, or bonus rewards on mobile app activity over the next 60 days."
        })
        
    # 2. High Balance Flight Risk
    if balance > 80000:
        recommendations.append({
            "trigger": f"High Deposit Balance at Risk (${balance:,.2f})",
            "action": "Assign Dedicated Premier Relationship Manager",
            "details": "Schedule a complimentary portfolio review with a private wealth advisor; offer preferential fixed-deposit yield rates (+50 bps) to lock in liquidity."
        })
        
    # 3. Product Portfolio Optimization
    if products >= 3:
        recommendations.append({
            "trigger": f"High Attrition Danger: Multi-Product Bundle ({products} products)",
            "action": "Comprehensive Fee & Product Audit",
            "details": "Conduct proactive customer satisfaction audit to consolidate fee schedules and resolve product complexity disputes that drive 80%+ churn in this tier."
        })
    elif products == 1:
        recommendations.append({
            "trigger": "Single Product Vulnerability",
            "action": "Targeted Cross-Sell with 2nd Product Sweet Spot",
            "details": "Customers holding 2 products exhibit the lowest churn (~7.6%). Offer an appealing high-yield savings account or auto insurance tie-up."
        })
        
    # 4. Regional Retention (Germany)
    if country == "Germany":
        recommendations.append({
            "trigger": "German Market High-Churn Exposure",
            "action": "Competitive Fee Benchmarking & Digital Enhancement",
            "details": "Ensure fee transparency and provide modern mobile contactless payment integrations to compete with aggressive local fintech challengers."
        })
        
    # 5. Senior Demographic Strategy
    if age >= 50:
        recommendations.append({
            "trigger": f"Senior Life-Stage Transition (Age {age})",
            "action": "Retirement & Estate Wealth Advisory",
            "details": "Offer priority branch appointments, dedicated senior telephone support, and streamlined retirement transition advisory services."
        })
        
    # Default baseline if low risk
    if not recommendations:
        recommendations.append({
            "trigger": "Stable Account Health",
            "action": "Loyalty Appreciation & Maintenance",
            "details": "Maintain regular communications via quarterly newsletter and thank-you rewards; monitor transaction volumes for early sentiment shifts."
        })
        
    return recommendations


def predict_single_customer(
    customer_dict: Dict[str, Any],
    model_choice: str = 'Random Forest (Recommended Champion)',
    models_dir: str = "models"
) -> Dict[str, Any]:
    """
    Preprocesses a single customer dictionary through the exact fitted pipeline
    and returns predictions, probability, risk tier, and retention actions.
    """
    pipeline = load_model_pipeline(model_choice, models_dir)
    
    # Construct single-row DataFrame matching training feature columns
    df_single = pd.DataFrame([customer_dict])
    df_single = standardize_columns(df_single)
    
    # Predict
    prob = float(pipeline.predict_proba(df_single)[0, 1])
    pred = int(pipeline.predict(df_single)[0])
    
    risk_label, risk_class, risk_color = categorize_risk(prob)
    recommendations = generate_retention_playbook(customer_dict, prob)
    
    # Identify top customer risk drivers
    drivers = []
    if customer_dict.get('Age', 0) >= 45:
        drivers.append(f"Elevated age ({customer_dict.get('Age')}) increases statistical churn likelihood.")
    if customer_dict.get('NumOfProducts', 1) in [3, 4]:
        drivers.append(f"Holding {customer_dict.get('NumOfProducts')} products has an ~82-100% empirical churn correlation.")
    if customer_dict.get('NumOfProducts', 1) == 1:
        drivers.append("Single-product holder (susceptible to competitor switching).")
    if customer_dict.get('IsActiveMember', 1) == 0:
        drivers.append("Inactive membership status significantly depresses retention.")
    if customer_dict.get('Geography') == 'Germany':
        drivers.append("German accounts exhibit 2x national churn rate.")
    if customer_dict.get('Balance', 0) > 90000:
        drivers.append("Substantial balance creates high financial defection impact.")
        
    if not drivers:
        drivers.append("Customer attributes align with long-term retention profile.")
        
    return {
        'prediction': "Likely to Churn" if pred == 1 else "Likely to Stay",
        'prediction_code': pred,
        'churn_probability': prob,
        'churn_probability_pct': round(prob * 100, 2),
        'risk_category': risk_label,
        'risk_class': risk_class,
        'risk_color': risk_color,
        'selected_model': model_choice,
        'key_drivers': drivers,
        'retention_playbook': recommendations,
        'customer_data': customer_dict
    }


def predict_bulk_customers(
    df_raw: pd.DataFrame,
    model_choice: str = 'Random Forest (Recommended Champion)',
    models_dir: str = "models"
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Processes an uploaded DataFrame in batch:
    - Validates columns
    - Scores probabilities
    - Assigns risk tiers
    - Enriches with actionable retention summaries
    """
    pipeline = load_model_pipeline(model_choice, models_dir)
    
    df = standardize_columns(df_raw.copy())
    
    # Validate required features
    missing_features = [col for col in (NUMERICAL_FEATURES + CATEGORICAL_FEATURES) if col not in df.columns]
    if missing_features:
        raise ValueError(f"Uploaded CSV is missing mandatory features: {', '.join(missing_features)}")
        
    # Score predictions
    probs = pipeline.predict_proba(df)[:, 1]
    preds = pipeline.predict(df)
    
    df_scored = df.copy()
    df_scored['Churn_Probability'] = (probs * 100).round(2)
    df_scored['Prediction'] = np.where(preds == 1, 'Likely to Churn', 'Likely to Stay')
    
    # Risk tiers
    def assign_risk(p):
        if p >= 65.0:
            return 'High Risk'
        elif p >= 35.0:
            return 'Medium Risk'
        else:
            return 'Low Risk'
            
    df_scored['Risk_Tier'] = df_scored['Churn_Probability'].apply(assign_risk)
    
    # Add prioritized recommended action
    def get_summary_action(row):
        if row['IsActiveMember'] == 0:
            return "Re-engagement incentive campaign"
        elif row['NumOfProducts'] >= 3:
            return "Product consolidation & dispute audit"
        elif row['Balance'] > 80000:
            return "Assign private wealth manager"
        elif row['NumOfProducts'] == 1:
            return "Cross-sell 2nd complementary product"
        else:
            return "Maintain standard relationship"
            
    df_scored['Recommended_Action'] = df_scored.apply(get_summary_action, axis=1)
    
    # Sort descending by Churn_Probability
    df_scored.sort_values(by='Churn_Probability', ascending=False, inplace=True)
    
    summary = {
        'total_evaluated': len(df_scored),
        'high_risk_count': int((df_scored['Risk_Tier'] == 'High Risk').sum()),
        'medium_risk_count': int((df_scored['Risk_Tier'] == 'Medium Risk').sum()),
        'low_risk_count': int((df_scored['Risk_Tier'] == 'Low Risk').sum()),
        'avg_churn_prob': float(df_scored['Churn_Probability'].mean()),
        'high_risk_balance_at_risk': float(df_scored[df_scored['Risk_Tier'] == 'High Risk']['Balance'].sum()) if 'Balance' in df_scored.columns else 0.0
    }
    
    return df_scored, summary


def generate_sample_csv(n_samples: int = 25) -> str:
    """Generates sample CSV data for user download and testing."""
    sample_data = {
        'CustomerId': range(15800001, 15800001 + n_samples),
        'Surname': ['Smith', 'Garcia', 'Mueller', 'Dubois', 'Novak', 'Rossi', 'Schmidt', 'Taylor', 'Hernandez', 'Lefebvre',
                    'Fischer', 'Moreau', 'Schneider', 'Kowalski', 'Martin', 'Weber', 'Roux', 'Vidal', 'Wagner', 'Fournier',
                    'Meyer', 'Gomez', 'Becker', 'Fontaine', 'Schulz'][:n_samples],
        'CreditScore': [650, 720, 510, 800, 590, 680, 490, 740, 610, 830,
                        550, 670, 710, 580, 620, 790, 480, 690, 750, 530,
                        640, 770, 600, 730, 820][:n_samples],
        'Geography': ['France', 'Germany', 'Spain', 'France', 'Germany', 'France', 'Germany', 'Spain', 'France', 'Germany',
                      'Spain', 'France', 'Germany', 'France', 'Spain', 'Germany', 'France', 'Spain', 'Germany', 'France',
                      'Germany', 'Spain', 'France', 'Germany', 'France'][:n_samples],
        'Gender': ['Female', 'Male', 'Female', 'Female', 'Male', 'Male', 'Female', 'Male', 'Female', 'Female',
                   'Male', 'Female', 'Male', 'Female', 'Male', 'Female', 'Male', 'Female', 'Male', 'Female',
                   'Male', 'Female', 'Male', 'Female', 'Male'][:n_samples],
        'Age': [42, 56, 31, 29, 64, 38, 49, 25, 45, 52,
                34, 41, 58, 27, 46, 39, 61, 33, 50, 44,
                55, 30, 48, 36, 63][:n_samples],
        'Tenure': [5, 2, 7, 1, 8, 4, 3, 9, 6, 2,
                   5, 8, 3, 6, 7, 4, 9, 1, 5, 4,
                   6, 3, 8, 2, 7][:n_samples],
        'Balance': [75000.0, 142000.0, 0.0, 95000.0, 118000.0, 0.0, 125000.0, 0.0, 88000.0, 160000.0,
                    0.0, 62000.0, 134000.0, 0.0, 91000.0, 105000.0, 112000.0, 0.0, 128000.0, 79000.0,
                    145000.0, 0.0, 87000.0, 99000.0, 155000.0][:n_samples],
        'NumOfProducts': [1, 3, 2, 2, 1, 2, 4, 2, 1, 3,
                          2, 1, 3, 2, 1, 2, 1, 2, 3, 1,
                          3, 2, 1, 2, 1][:n_samples],
        'HasCrCard': [1, 1, 0, 1, 1, 0, 1, 1, 0, 1,
                      1, 0, 1, 1, 1, 0, 1, 1, 1, 0,
                      1, 1, 0, 1, 1][:n_samples],
        'IsActiveMember': [0, 0, 1, 1, 0, 1, 0, 1, 0, 0,
                           1, 1, 0, 1, 0, 1, 0, 1, 0, 1,
                           0, 1, 0, 1, 0][:n_samples],
        'EstimatedSalary': [105000.0, 125000.0, 85000.0, 110000.0, 78000.0, 92000.0, 135000.0, 65000.0, 98000.0, 145000.0,
                            72000.0, 89000.0, 131000.0, 68000.0, 104000.0, 115000.0, 82000.0, 94000.0, 122000.0, 86000.0,
                            138000.0, 79000.0, 99000.0, 108000.0, 152000.0][:n_samples]
    }
    df_sample = pd.DataFrame(sample_data)
    return df_sample.to_csv(index=False)

