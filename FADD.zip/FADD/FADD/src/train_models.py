"""
Machine Learning Training Pipeline for Bank Customer Churn Prediction.
Builds, trains, evaluates, and persists:
1. Logistic Regression
2. Decision Tree Classifier
3. Random Forest Classifier
4. Gradient Boosting Classifier
Bundled with Scikit-learn Pipeline and ColumnTransformer to eliminate data leakage.
"""

import os
import sys
import json
import logging
from typing import Dict, Any, Tuple

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import numpy as np
import pandas as pd
import joblib

from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report, roc_curve
)

from src.data_preprocessing import (
    load_data, prepare_train_test_data, build_preprocessor,
    get_transformed_feature_names
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def get_model_definitions() -> Dict[str, Any]:
    """Defines candidate ML classifiers with tuned hyperparameters and class balancing."""
    return {
        'Logistic Regression': LogisticRegression(
            C=1.0,
            max_iter=1000,
            class_weight='balanced',
            solver='lbfgs',
            random_state=42
        ),
        'Decision Tree': DecisionTreeClassifier(
            max_depth=6,
            min_samples_split=20,
            min_samples_leaf=10,
            class_weight='balanced',
            criterion='gini',
            random_state=42
        ),
        'Random Forest': RandomForestClassifier(
            n_estimators=150,
            max_depth=10,
            min_samples_split=15,
            min_samples_leaf=5,
            class_weight='balanced',
            max_features='sqrt',
            random_state=42,
            n_jobs=-1
        ),
        'Gradient Boosting': GradientBoostingClassifier(
            n_estimators=160,
            learning_rate=0.08,
            max_depth=4,
            subsample=0.85,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=42
        )
    }


def evaluate_single_pipeline(
    pipeline: Pipeline,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    cv_splits: int = 5
) -> Dict[str, Any]:
    """Computes comprehensive evaluation metrics on train, test, and cross-validation."""
    # Predictions
    y_pred = pipeline.predict(X_test)
    y_prob = pipeline.predict_proba(X_test)[:, 1]
    
    # Core Metrics
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    auc = roc_auc_score(y_test, y_prob)
    
    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred).tolist()
    
    # Classification Report
    cr = classification_report(y_test, y_pred, output_dict=True)
    
    # ROC Curve Data Points (downsampled for lightweight serialization)
    fpr, tpr, thresholds = roc_curve(y_test, y_prob)
    stride = max(1, len(fpr) // 100)
    roc_points = {
        'fpr': fpr[::stride].tolist(),
        'tpr': tpr[::stride].tolist(),
        'thresholds': thresholds[::stride].tolist()
    }
    
    # 5-Fold Stratified Cross-Validation on Training Data
    cv = StratifiedKFold(n_splits=cv_splits, shuffle=True, random_state=42)
    cv_scores_auc = cross_val_score(pipeline, X_train, y_train, cv=cv, scoring='roc_auc', n_jobs=-1)
    cv_scores_f1 = cross_val_score(pipeline, X_train, y_train, cv=cv, scoring='f1', n_jobs=-1)
    
    return {
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1_score': float(f1),
        'roc_auc': float(auc),
        'cv_auc_mean': float(cv_scores_auc.mean()),
        'cv_auc_std': float(cv_scores_auc.std()),
        'cv_f1_mean': float(cv_scores_f1.mean()),
        'cv_f1_std': float(cv_scores_f1.std()),
        'confusion_matrix': cm,
        'classification_report': cr,
        'roc_curve': roc_points
    }


def train_and_save_all_models(
    data_path: str = "data/Churn_Modelling.csv",
    models_dir: str = "models"
) -> Tuple[Dict[str, Pipeline], Dict[str, Any], str]:
    """
    Executes the complete ML training pipeline:
    1. Loads dataset
    2. Performs stratified train-test split
    3. Builds preprocessor
    4. Fits Scikit-learn Pipeline for each model
    5. Evaluates on holdout test set
    6. Identifies best model via ROC-AUC & Recall strategy
    7. Persists models and metrics
    """
    os.makedirs(models_dir, exist_ok=True)
    
    logging.info(f"Loading data from {data_path}...")
    df = load_data(data_path)
    X_train, X_test, y_train, y_test = prepare_train_test_data(df, test_size=0.2, random_state=42)
    
    # Preprocessor is fit strictly inside the pipelines during pipeline.fit(X_train, y_train)
    raw_models = get_model_definitions()
    trained_pipelines: Dict[str, Pipeline] = {}
    evaluation_results: Dict[str, Any] = {}
    
    # Fit and save standalone preprocessor for inspectability
    standalone_preprocessor = build_preprocessor()
    standalone_preprocessor.fit(X_train)
    joblib.dump(standalone_preprocessor, os.path.join(models_dir, "preprocessor.pkl"))
    feature_names = get_transformed_feature_names(standalone_preprocessor)
    
    file_key_map = {
        'Logistic Regression': 'logistic_regression.pkl',
        'Decision Tree': 'decision_tree.pkl',
        'Random Forest': 'random_forest.pkl',
        'Gradient Boosting': 'gradient_boosting.pkl'
    }
    
    for model_name, classifier in raw_models.items():
        logging.info(f"Training pipeline: {model_name}...")
        preprocessor = build_preprocessor()
        pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('classifier', classifier)
        ])
        
        # Fit on training data only
        pipeline.fit(X_train, y_train)
        
        # Evaluate on holdout test data
        metrics = evaluate_single_pipeline(pipeline, X_train, y_train, X_test, y_test)
        
        trained_pipelines[model_name] = pipeline
        evaluation_results[model_name] = metrics
        
        # Persist individual model pipeline
        filename = file_key_map[model_name]
        joblib.dump(pipeline, os.path.join(models_dir, filename))
        logging.info(f"Saved {model_name} to {filename} with Test ROC-AUC: {metrics['roc_auc']:.4f}, Recall: {metrics['recall']:.4f}")
        
    # Best Model Selection Strategy:
    # In banking churn prediction, an effective production model must balance discrimination (ROC-AUC)
    # with harmonic precision-recall (F1-score) to prevent both catastrophic false negatives and wasteful false alarms.
    # Score = 0.5 * ROC_AUC + 0.5 * F1_Score
    best_model_name = max(
        evaluation_results.keys(),
        key=lambda m: (0.5 * evaluation_results[m]['roc_auc'] + 0.5 * evaluation_results[m]['f1_score'])
    )
    
    logging.info(f"Selected Champion Model: {best_model_name} (Composite F1+AUC Score: {0.5 * evaluation_results[best_model_name]['roc_auc'] + 0.5 * evaluation_results[best_model_name]['f1_score']:.4f})")
    
    # Save best model copy
    joblib.dump(trained_pipelines[best_model_name], os.path.join(models_dir, "best_model.pkl"))
    
    # Package metadata for dashboard loading
    metadata = {
        'best_model_name': best_model_name,
        'selection_criteria': 'Balanced Champion Strategy: 50% ROC-AUC + 50% F1-Score to maximize discrimination while maintaining balanced precision and recall.',
        'feature_names': feature_names,
        'evaluation_results': evaluation_results,
        'train_samples': len(X_train),
        'test_samples': len(X_test),
        'train_churn_rate': float(y_train.mean()),
        'test_churn_rate': float(y_test.mean())
    }
    
    with open(os.path.join(models_dir, "model_metrics.json"), "w") as f:
        json.dump(metadata, f, indent=2)
        
    # Also save test set for real-time dashboard evaluations
    test_data = X_test.copy()
    test_data['Exited'] = y_test
    test_data.to_csv(os.path.join(models_dir, "test_dataset.csv"), index=False)
    
    logging.info("Training complete and all artifacts persisted successfully.")
    return trained_pipelines, metadata, best_model_name


if __name__ == "__main__":
    train_and_save_all_models()
