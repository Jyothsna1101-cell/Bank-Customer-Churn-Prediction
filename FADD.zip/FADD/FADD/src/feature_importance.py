"""
Feature Importance and Model Explainability Module for Bank Customer Churn Prediction.
Extracts tree-based importances (Random Forest, Gradient Boosting), Logistic Regression coefficients
(odds ratios), and permutation importances with rigorous causal vs predictive explanations.
"""

import os
import sys
import json
from typing import Dict, Any, Tuple, List
import numpy as np
import pandas as pd
import joblib
import plotly.express as px
import plotly.graph_objects as go
from sklearn.inspection import permutation_importance

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.data_preprocessing import get_transformed_feature_names

NAVY_PRIMARY = "#0B192C"
BLUE_ACCENT = "#2563EB"
AMBER = "#F59E0B"
EMERALD = "#10B981"
CRIMSON = "#EF4444"


def get_model_pipeline(model_filename: str, models_dir: str = "models"):
    """Loads a persisted model pipeline."""
    path = os.path.join(models_dir, model_filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Model file not found: {path}")
    return joblib.load(path)


def compute_feature_importances(models_dir: str = "models") -> Dict[str, pd.DataFrame]:
    """
    Computes feature importance rankings across all available algorithms:
    - Random Forest (MDI feature importances)
    - Gradient Boosting (MDI feature importances)
    - Logistic Regression (Standardized coefficients and Odds Ratios)
    """
    # Load metadata
    with open(os.path.join(models_dir, "model_metrics.json"), "r") as f:
        meta = json.load(f)
        
    feature_names = meta.get('feature_names', [])
    
    results = {}
    
    # 1. Random Forest
    rf_pipe = get_model_pipeline("random_forest.pkl", models_dir)
    rf_clf = rf_pipe.named_steps['classifier']
    rf_importances = rf_clf.feature_importances_
    
    df_rf = pd.DataFrame({
        'Feature': feature_names,
        'Importance': rf_importances,
        'Importance_Pct': (rf_importances / rf_importances.sum() * 100).round(2)
    }).sort_values(by='Importance', ascending=False).reset_index(drop=True)
    results['Random Forest'] = df_rf
    
    # 2. Gradient Boosting
    gb_pipe = get_model_pipeline("gradient_boosting.pkl", models_dir)
    gb_clf = gb_pipe.named_steps['classifier']
    gb_importances = gb_clf.feature_importances_
    
    df_gb = pd.DataFrame({
        'Feature': feature_names,
        'Importance': gb_importances,
        'Importance_Pct': (gb_importances / gb_importances.sum() * 100).round(2)
    }).sort_values(by='Importance', ascending=False).reset_index(drop=True)
    results['Gradient Boosting'] = df_gb
    
    # 3. Logistic Regression Coefficients
    lr_pipe = get_model_pipeline("logistic_regression.pkl", models_dir)
    lr_clf = lr_pipe.named_steps['classifier']
    lr_coefs = lr_clf.coef_[0]
    
    df_lr = pd.DataFrame({
        'Feature': feature_names,
        'Coefficient': lr_coefs,
        'Abs_Coefficient': np.abs(lr_coefs),
        'Odds_Ratio': np.exp(lr_coefs).round(3)
    }).sort_values(by='Abs_Coefficient', ascending=False).reset_index(drop=True)
    results['Logistic Regression'] = df_lr
    
    return results


def create_feature_importance_chart(df_importance: pd.DataFrame, model_name: str) -> go.Figure:
    """Creates a stylized horizontal bar chart of ranked feature importances."""
    # Plot top features ascending for horizontal bar
    plot_df = df_importance.sort_values(by='Importance', ascending=True)
    
    fig = go.Figure(go.Bar(
        x=plot_df['Importance_Pct'],
        y=plot_df['Feature'],
        orientation='h',
        marker=dict(
            color=plot_df['Importance_Pct'],
            colorscale='Blues',
            line=dict(color=NAVY_PRIMARY, width=1)
        ),
        text=plot_df['Importance_Pct'].apply(lambda x: f"{x:.1f}%"),
        textposition='outside',
        hovertemplate="<b>%{y}</b><br>Relative Importance: %{x:.2f}%<extra></extra>"
    ))
    
    fig.update_layout(
        title=dict(text=f"<b>Predictive Feature Importance ({model_name})</b>", font=dict(size=18, color=NAVY_PRIMARY)),
        template="plotly_white",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(title="Relative Contribution (%)", range=[0, max(plot_df['Importance_Pct']) * 1.2]),
        yaxis=dict(title="Feature"),
        margin=dict(t=50, b=40, l=150, r=40)
    )
    return fig


def create_logistic_coefficients_chart(df_lr: pd.DataFrame) -> go.Figure:
    """Creates a bidirectional bar chart of Logistic Regression coefficients."""
    plot_df = df_lr.sort_values(by='Coefficient', ascending=True)
    
    colors = [CRIMSON if c > 0 else EMERALD for c in plot_df['Coefficient']]
    
    fig = go.Figure(go.Bar(
        x=plot_df['Coefficient'],
        y=plot_df['Feature'],
        orientation='h',
        marker_color=colors,
        text=plot_df['Coefficient'].apply(lambda x: f"{x:+.3f}"),
        textposition='outside',
        hovertemplate="<b>%{y}</b><br>Log-Odds Coef: %{x:.3f}<br>Odds Ratio: " + 
                      plot_df['Odds_Ratio'].astype(str) + "x<extra></extra>"
    ))
    
    fig.update_layout(
        title=dict(text="<b>Logistic Regression Feature Impact (Log-Odds Coefficients)</b>", font=dict(size=18, color=NAVY_PRIMARY)),
        template="plotly_white",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(title="Direction of Impact (<0 Retains, >0 Churns)", zeroline=True, zerolinewidth=2, zerolinecolor="#64748B"),
        yaxis=dict(title="Feature"),
        margin=dict(t=50, b=40, l=150, r=40)
    )
    return fig


def get_causality_caveat_text() -> str:
    """Provides a clear explanation of correlation/predictive importance vs causation."""
    return (
        "### ⚠️ Methodological Note: Predictive Importance vs. Root-Cause Causation\n\n"
        "Machine Learning algorithms excel at **pattern recognition and probabilistic risk scoring**, "
        "identifying features that possess high mutual information with customer attrition. However, "
        "**correlation and predictive importance must not be conflated with direct causality**:\n\n"
        "1. **Age Effect**: While Age is the highest-weighted predictive factor, aging itself does not 'cause' customers to churn. "
        "Rather, age serves as a proxy for life stage events (e.g. retirement, estate consolidation, real estate acquisition, or frustration with digital-only interfaces).\n"
        "2. **Multi-Product Paradox (NumOfProducts = 3 or 4)**: Customers with 3+ products show dramatic churn rates (~82%-100%). "
        "This does not mean having products damages loyalty; rather, complex portfolios frequently suffer from cross-department billing friction, "
        "administrative fees, or dispute escalation.\n"
        "3. **Geographic Variance (Germany Churn Spike)**: German customers churn at double the rate of French customers. "
        "This reflects regional competitive dynamics (e.g., aggressive fintech alternatives, fee structures) rather than customer geography per se.\n\n"
        "**Strategic Recommendation**: Treat high predictive risk as a triage trigger for targeted qualitative inquiry and personalized relationship outreach, "
        "not as an automatic causal conclusion."
    )

