"""
Data Preprocessing Module for Bank Customer Churn Prediction System.
Handles dataset loading, column normalization, cleaning, feature transformation,
and stratified train-test splitting without data leakage.
"""

import os
from typing import Tuple, List, Union, Optional
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
import joblib

# Standardized column names and lists
RAW_COLUMN_MAPPING = {
    'num of products': 'NumOfProducts',
    'numofproducts': 'NumOfProducts',
    'has credit card': 'HasCrCard',
    'hascrcard': 'HasCrCard',
    'is active member': 'IsActiveMember',
    'isactivemember': 'IsActiveMember',
    'estimated salary': 'EstimatedSalary',
    'estimatedsalary': 'EstimatedSalary',
    'credit score': 'CreditScore',
    'creditscore': 'CreditScore',
    'churn': 'Exited',
    'exited': 'Exited'
}

NUMERICAL_FEATURES = [
    'CreditScore', 'Age', 'Tenure', 'Balance', 
    'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary'
]

CATEGORICAL_FEATURES = ['Geography', 'Gender']

IRRELEVANT_COLUMNS = ['RowNumber', 'CustomerId', 'Surname']

TARGET_COLUMN = 'Exited'


def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Standardizes column names to standard Kaggle Churn Modelling convention."""
    df_clean = df.copy()
    col_map = {}
    for col in df_clean.columns:
        norm_key = str(col).strip().lower()
        if norm_key in RAW_COLUMN_MAPPING:
            col_map[col] = RAW_COLUMN_MAPPING[norm_key]
        else:
            # Match case insensitive without spaces
            for k, v in RAW_COLUMN_MAPPING.items():
                if norm_key.replace(" ", "").replace("_", "") == k.replace(" ", ""):
                    col_map[col] = v
                    break
    df_clean.rename(columns=col_map, inplace=True)
    return df_clean


def load_data(filepath_or_buffer: Union[str, object] = "data/Churn_Modelling.csv") -> pd.DataFrame:
    """
    Loads dataset from a CSV path or file buffer, standardizes columns,
    and returns a cleaned DataFrame.
    """
    if isinstance(filepath_or_buffer, str) and not os.path.exists(filepath_or_buffer):
        raise FileNotFoundError(f"Dataset file not found at: {filepath_or_buffer}")
    
    df = pd.read_csv(filepath_or_buffer)
    df = standardize_columns(df)
    
    # Strip whitespace on string/categorical columns
    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].astype(str).str.strip()
        
    return df


def get_data_summary(df: pd.DataFrame) -> dict:
    """Returns dataset summary metrics for dashboard display."""
    total_records = len(df)
    duplicates = int(df.duplicated().sum())
    missing_values = int(df.isnull().sum().sum())
    
    churn_count = int(df[TARGET_COLUMN].sum()) if TARGET_COLUMN in df.columns else None
    retained_count = total_records - churn_count if churn_count is not None else None
    churn_rate = (churn_count / total_records * 100) if churn_count is not None else None
    
    return {
        'total_rows': total_records,
        'total_columns': df.shape[1],
        'duplicates': duplicates,
        'missing_values': missing_values,
        'churn_count': churn_count,
        'retained_count': retained_count,
        'churn_rate': churn_rate,
        'avg_age': float(df['Age'].mean()) if 'Age' in df.columns else None,
        'avg_balance': float(df['Balance'].mean()) if 'Balance' in df.columns else None,
        'avg_credit_score': float(df['CreditScore'].mean()) if 'CreditScore' in df.columns else None,
        'countries': df['Geography'].unique().tolist() if 'Geography' in df.columns else []
    }


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Removes duplicates and handles missing values."""
    df_clean = df.copy()
    df_clean = df_clean.drop_duplicates()
    
    # Impute numerical features with median
    for num_col in NUMERICAL_FEATURES:
        if num_col in df_clean.columns and df_clean[num_col].isnull().sum() > 0:
            df_clean[num_col].fillna(df_clean[num_col].median(), inplace=True)
            
    # Impute categorical features with mode
    for cat_col in CATEGORICAL_FEATURES:
        if cat_col in df_clean.columns and df_clean[cat_col].isnull().sum() > 0:
            mode_val = df_clean[cat_col].mode()[0]
            df_clean[cat_col].fillna(mode_val, inplace=True)
            
    return df_clean


def get_feature_target_split(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Separates independent features (X) and target variable (y).
    Drops non-predictive identifiers (RowNumber, CustomerId, Surname).
    """
    df_clean = clean_dataset(df)
    
    cols_to_drop = [c for c in IRRELEVANT_COLUMNS if c in df_clean.columns]
    if TARGET_COLUMN in df_clean.columns:
        cols_to_drop.append(TARGET_COLUMN)
        
    X = df_clean.drop(columns=cols_to_drop)
    y = df_clean[TARGET_COLUMN] if TARGET_COLUMN in df_clean.columns else None
    
    return X, y


def build_preprocessor() -> ColumnTransformer:
    """
    Creates an industry-standard ColumnTransformer pipeline:
    - Numerical: SimpleImputer (median) -> StandardScaler
    - Categorical: SimpleImputer (most_frequent) -> OneHotEncoder(drop='first', handle_unknown='ignore')
    """
    num_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    
    cat_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(drop='first', sparse_output=False, handle_unknown='ignore'))
    ])
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', num_pipeline, NUMERICAL_FEATURES),
            ('cat', cat_pipeline, CATEGORICAL_FEATURES)
        ],
        remainder='drop'
    )
    
    return preprocessor


def get_transformed_feature_names(preprocessor: ColumnTransformer) -> List[str]:
    """Extracts explicit feature names after transformation for explainability."""
    feature_names = []
    
    # Numerical feature names
    feature_names.extend(NUMERICAL_FEATURES)
    
    # Categorical one-hot encoded feature names
    try:
        cat_encoder = preprocessor.named_transformers_['cat'].named_steps['onehot']
        ohe_cols = cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES).tolist()
        feature_names.extend(ohe_cols)
    except Exception:
        # Fallback default names for Geography and Gender
        feature_names.extend(['Geography_Germany', 'Geography_Spain', 'Gender_Male'])
        
    return feature_names


def prepare_train_test_data(
    df: pd.DataFrame, 
    test_size: float = 0.2, 
    random_state: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """
    Splits dataset into stratified training and testing sets to prevent data leakage
    and preserve class distribution.
    """
    X, y = get_feature_target_split(df)
    if y is None:
        raise ValueError("Target column 'Exited' must be present in the dataset.")
        
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, 
        test_size=test_size, 
        random_state=random_state, 
        stratify=y
    )
    
    return X_train, X_test, y_train, y_test

