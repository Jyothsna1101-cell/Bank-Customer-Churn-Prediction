"""
Model Evaluation and Comparison Module for Bank Customer Churn Prediction.
Generates comprehensive comparative tables, interactive ROC curves, confusion matrix
heatmaps, and metric visualizations for executive review.
"""

import os
import sys
import json
from typing import Dict, Any, Tuple
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

NAVY_PRIMARY = "#0B192C"
NAVY_SECONDARY = "#1E3E62"
BLUE_ACCENT = "#2563EB"
EMERALD = "#10B981"
CRIMSON = "#EF4444"
AMBER = "#F59E0B"
PURPLE = "#8B5CF6"


def load_evaluation_metadata(models_dir: str = "models") -> Dict[str, Any]:
    """Loads saved model metrics and metadata."""
    meta_path = os.path.join(models_dir, "model_metrics.json")
    if not os.path.exists(meta_path):
        raise FileNotFoundError(f"Model metrics not found at: {meta_path}. Please train models first.")
    with open(meta_path, "r") as f:
        return json.load(f)


def get_comparison_dataframe(metadata: Dict[str, Any]) -> pd.DataFrame:
    """Creates a formatted model comparison DataFrame."""
    eval_results = metadata['evaluation_results']
    rows = []
    
    for name, m in eval_results.items():
        rows.append({
            'Model': name,
            'Accuracy': round(m['accuracy'] * 100, 2),
            'Precision': round(m['precision'] * 100, 2),
            'Recall': round(m['recall'] * 100, 2),
            'F1-Score': round(m['f1_score'] * 100, 2),
            'ROC-AUC': round(m['roc_auc'], 4),
            '5-Fold CV AUC': f"{m['cv_auc_mean']:.3f} ± {m['cv_auc_std']:.3f}"
        })
        
    df_comp = pd.DataFrame(rows)
    # Sort by ROC-AUC descending
    df_comp.sort_values(by='ROC-AUC', ascending=False, inplace=True)
    return df_comp


def create_model_comparison_chart(metadata: Dict[str, Any]) -> go.Figure:
    """Grouped bar chart comparing key performance metrics across all 4 models."""
    eval_results = metadata['evaluation_results']
    models = list(eval_results.keys())
    
    metrics = ['accuracy', 'precision', 'recall', 'f1_score']
    metric_labels = ['Accuracy (%)', 'Precision (%)', 'Recall (%)', 'F1-Score (%)']
    colors = [NAVY_PRIMARY, AMBER, CRIMSON, EMERALD]
    
    fig = go.Figure()
    
    for metric_key, label, color in zip(metrics, metric_labels, colors):
        values = [round(eval_results[m][metric_key] * 100, 2) for m in models]
        fig.add_trace(go.Bar(
            name=label,
            x=models,
            y=values,
            marker_color=color,
            text=[f"{v:.1f}%" for v in values],
            textposition='outside',
            hovertemplate=f"<b>%{{x}}</b><br>{label}: %{{y:.2f}}%<extra></extra>"
        ))
        
    fig.update_layout(
        title=dict(text="<b>Multi-Metric Model Performance Comparison</b>", font=dict(size=18, color=NAVY_PRIMARY)),
        barmode='group',
        template="plotly_white",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        yaxis=dict(title="Score (%)", range=[0, 105]),
        xaxis=dict(title="Machine Learning Algorithm"),
        legend=dict(orientation="h", yanchor="bottom", y=-0.25, xanchor="center", x=0.5),
        margin=dict(t=50, b=50, l=40, r=20)
    )
    return fig


def create_roc_curves_chart(metadata: Dict[str, Any]) -> go.Figure:
    """Comparative ROC curves for all 4 models with AUC in legend."""
    eval_results = metadata['evaluation_results']
    palette = [NAVY_PRIMARY, AMBER, EMERALD, BLUE_ACCENT]
    
    fig = go.Figure()
    
    for (name, m), color in zip(eval_results.items(), palette):
        roc_data = m['roc_curve']
        auc_val = m['roc_auc']
        fig.add_trace(go.Scatter(
            x=roc_data['fpr'],
            y=roc_data['tpr'],
            mode='lines',
            name=f"{name} (AUC = {auc_val:.4f})",
            line=dict(color=color, width=2.5),
            hovertemplate=f"<b>{name}</b><br>FPR: %{{x:.3f}}<br>TPR: %{{y:.3f}}<extra></extra>"
        ))
        
    # Baseline diagonal (random classifier)
    fig.add_trace(go.Scatter(
        x=[0, 1], y=[0, 1],
        mode='lines',
        name='Random Chance (AUC = 0.5000)',
        line=dict(color=SLATE_GRAY if 'SLATE_GRAY' in locals() else '#94A3B8', dash='dash', width=1.5)
    ))
    
    fig.update_layout(
        title=dict(text="<b>Receiver Operating Characteristic (ROC) Curves</b>", font=dict(size=18, color=NAVY_PRIMARY)),
        template="plotly_white",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(title="False Positive Rate (1 - Specificity)", range=[-0.01, 1.01]),
        yaxis=dict(title="True Positive Rate (Sensitivity / Recall)", range=[-0.01, 1.02]),
        legend=dict(orientation="h", yanchor="bottom", y=-0.3, xanchor="center", x=0.5),
        margin=dict(t=50, b=60, l=40, r=20)
    )
    return fig


def create_confusion_matrix_heatmap(metadata: Dict[str, Any], model_name: str) -> go.Figure:
    """Interactive Confusion Matrix heatmap with percentages and counts."""
    cm = np.array(metadata['evaluation_results'][model_name]['confusion_matrix'])
    
    tn, fp = cm[0]
    fn, tp = cm[1]
    total = tn + fp + fn + tp
    
    labels = [
        [f"True Negative (Retained)<br>Count: {tn:,}<br>({tn/total*100:.1f}%)",
         f"False Positive (False Alarm)<br>Count: {fp:,}<br>({fp/total*100:.1f}%)"],
        [f"False Negative (Missed Churn)<br>Count: {fn:,}<br>({fn/total*100:.1f}%)",
         f"True Positive (Caught Churn)<br>Count: {tp:,}<br>({tp/total*100:.1f}%)"]
    ]
    
    fig = go.Figure(data=go.Heatmap(
        z=cm,
        x=['Predicted Retained (0)', 'Predicted Churned (1)'],
        y=['Actual Retained (0)', 'Actual Churned (1)'],
        colorscale='Blues',
        text=labels,
        texttemplate="%{text}",
        textfont={"size": 13},
        hoverongaps=False,
        showscale=False
    ))
    
    fig.update_layout(
        title=dict(text=f"<b>Confusion Matrix: {model_name}</b>", font=dict(size=16, color=NAVY_PRIMARY)),
        template="plotly_white",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(side="bottom"),
        yaxis=dict(autorange="reversed"),
        margin=dict(t=40, b=40, l=60, r=40)
    )
    return fig


def get_classification_report_table(metadata: Dict[str, Any], model_name: str) -> pd.DataFrame:
    """Formats classification report into a styled table."""
    cr = metadata['evaluation_results'][model_name]['classification_report']
    rows = []
    
    for class_key, display_name in [('0', 'Class 0 (Retained)'), ('1', 'Class 1 (Churned)')]:
        if class_key in cr:
            rows.append({
                'Class': display_name,
                'Precision': f"{cr[class_key]['precision']*100:.2f}%",
                'Recall': f"{cr[class_key]['recall']*100:.2f}%",
                'F1-Score': f"{cr[class_key]['f1-score']*100:.2f}%",
                'Support': int(cr[class_key]['support'])
            })
            
    # Add macro and weighted averages
    for avg_key, display_name in [('macro avg', 'Macro Average'), ('weighted avg', 'Weighted Average')]:
        if avg_key in cr:
            rows.append({
                'Class': display_name,
                'Precision': f"{cr[avg_key]['precision']*100:.2f}%",
                'Recall': f"{cr[avg_key]['recall']*100:.2f}%",
                'F1-Score': f"{cr[avg_key]['f1-score']*100:.2f}%",
                'Support': int(cr[avg_key]['support'])
            })
            
    return pd.DataFrame(rows)

