"""
UI Helpers and Reusable Component Module for Bank Customer Churn System.
Provides unified CSS injection, header banners, metric cards, and sidebar styling.
"""

import os
import sys
import pandas as pd
import streamlit as st

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.data_preprocessing import load_data, get_data_summary


def load_custom_css():
    """Injects custom enterprise CSS into the Streamlit app."""
    css_path = os.path.join(PROJECT_ROOT, "assets", "custom.css")
    if os.path.exists(css_path):
        with open(css_path, "r", encoding="utf-8") as f:
            css_content = f.read()
        st.markdown(f"<style>{css_content}</style>", unsafe_allow_html=True)


def render_header(title: str, subtitle: str, badge_text: str = "ENTERPRISE ML PLATFORM"):
    """Renders a standard corporate navy header banner."""
    st.markdown(f"""
    <div class="bank-header-banner">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px;">
            <div>
                <h1 class="bank-header-title">🏛️ {title}</h1>
                <p class="bank-header-subtitle">{subtitle}</p>
            </div>
            <div>
                <span style="background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; letter-spacing: 0.8px; text-transform: uppercase; color: #FFFFFF;">
                    {badge_text}
                </span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_metric_card(label: str, value: str, delta: str = None, status: str = "info"):
    """
    Renders a styled corporate KPI card.
    status: 'info', 'success', 'warning', 'danger'
    """
    delta_html = ""
    if delta:
        delta_class = "neutral"
        if "+" in delta or "↑" in delta:
            delta_class = "positive" if status == "success" else "negative"
        elif "-" in delta or "↓" in delta:
            delta_class = "negative" if status == "danger" else "positive"
        delta_html = f'<div class="kpi-delta {delta_class}">{delta}</div>'
        
    card_html = f"""
    <div class="kpi-card kpi-{status}">
        <div class="kpi-label">{label}</div>
        <div class="kpi-value">{value}</div>
        {delta_html}
    </div>
    """
    st.markdown(card_html, unsafe_allow_html=True)


def render_sidebar():
    """Renders corporate branding, dataset status, and global controls in the sidebar."""
    with st.sidebar:
        st.markdown("""
        <div style="padding: 10px 0 20px 0; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 20px;">
            <div style="font-size: 18px; font-weight: 800; color: #FFFFFF; display: flex; align-items: center; gap: 8px;">
                <span>🛡️</span> ApexBank Analytics
            </div>
            <div style="font-size: 12px; color: #94A3B8; margin-top: 4px;">
                Customer Retention Intelligence 2.0
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("### 📊 Active Dataset")
        data_path = os.path.join(PROJECT_ROOT, "data", "Churn_Modelling.csv")
        
        if os.path.exists(data_path):
            st.success("✅ Kaggle Benchmark Dataset Loaded (10,000 Customers)")
        else:
            st.warning("⚠️ Local dataset missing. Please upload or fetch.")
            
        uploaded_file = st.file_uploader(
            "Upload Custom Dataset (CSV)",
            type=['csv'],
            key="global_sidebar_csv_uploader",
            help="Upload a replacement Kaggle Churn Modelling CSV file."
        )
        if uploaded_file is not None:
            try:
                df_custom = load_data(uploaded_file)
                st.session_state['active_df'] = df_custom
                st.success(f"Custom data loaded: {len(df_custom):,} rows")
            except Exception as e:
                st.error(f"Error parsing CSV: {e}")
                
        st.markdown("---")
        st.markdown("""
        <div style="font-size: 11px; color: #94A3B8; line-height: 1.6;">
            <b>Industry Standard:</b> Banking ML Suite<br>
            <b>Pipeline:</b> Scikit-Learn Pipelines<br>
            <b>Champion Model:</b> Random Forest<br>
            <b>Evaluation Focus:</b> ROC-AUC & Recall<br>
            <b>Version:</b> 2.4.0 (Enterprise)
        </div>
        """, unsafe_allow_html=True)


def get_current_dataset() -> pd.DataFrame:
    """Returns currently loaded dataset (from session state or disk)."""
    if 'active_df' in st.session_state:
        return st.session_state['active_df']
    
    data_path = os.path.join(PROJECT_ROOT, "data", "Churn_Modelling.csv")
    if os.path.exists(data_path):
        df = load_data(data_path)
        st.session_state['active_df'] = df
        return df
    else:
        raise FileNotFoundError("No dataset available. Please upload a CSV.")

