$procs = Get-Process -Name "PBIDesktop" -ErrorAction SilentlyContinue
if ($procs) {
    foreach ($p in $procs) {
        Write-Host "PBIDesktop ID: $($p.Id), MainWindowTitle: '$($p.MainWindowTitle)', Handle: $($p.MainWindowHandle)"
    }
} else {
    Write-Host "No PBIDesktop processes found."
}

