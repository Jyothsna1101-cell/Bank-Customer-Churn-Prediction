"""
Data and ML Result Generator for Microsoft Power BI Dashboard.
Extracts, cleans, and exports:
1. Customers_Cleaned.csv
2. Customer_Churn_Predictions.csv
3. Model_Evaluation.csv
4. Feature_Importance.csv
5. Confusion_Matrix_Data.csv
6. ROC_Curve_Data.csv
"""

import os
import sys
import json
import numpy as np
import pandas as pd
import joblib

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.data_preprocessing import load_data, clean_dataset, NUMERICAL_FEATURES, CATEGORICAL_FEATURES
from src.prediction import categorize_risk, generate_retention_playbook
from src.feature_importance import compute_feature_importances

OUTPUT_DIR = os.path.join(PROJECT_ROOT, "PowerBI_Dashboard")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def export_cleaned_customers():
    """Generates Customers_Cleaned.csv with descriptive dimensions and cohorts."""
    print("Generating Customers_Cleaned.csv...")
    df = load_data(os.path.join(PROJECT_ROOT, "data", "Churn_Modelling.csv"))
    df = clean_dataset(df)
    
    # Drop RowNumber if present, retain CustomerId for relationships
    if 'RowNumber' in df.columns:
        df.drop(columns=['RowNumber'], inplace=True)
        
    # Add human-readable descriptive columns for Power BI slicers and charts
    df['Exited_Label'] = df['Exited'].map({0: 'Retained', 1: 'Churned'})
    df['IsActiveMember_Label'] = df['IsActiveMember'].map({1: 'Active Member', 0: 'Inactive Member'})
    df['HasCrCard_Label'] = df['HasCrCard'].map({1: 'Has Credit Card', 0: 'No Credit Card'})
    
    # Age Group Binning
    bins_age = [18, 30, 40, 50, 60, 70, 100]
    labels_age = ['18-29 Years', '30-39 Years', '40-49 Years', '50-59 Years', '60-69 Years', '70+ Years']
    df['AgeGroup'] = pd.cut(df['Age'], bins=bins_age, labels=labels_age, right=False)
    
    # Credit Score Tiers (FICO benchmark)
    bins_credit = [300, 580, 670, 740, 800, 900]
    labels_credit = ['Poor (<580)', 'Fair (580-669)', 'Good (670-739)', 'Very Good (740-799)', 'Exceptional (800+)']
    df['CreditScoreTier'] = pd.cut(df['CreditScore'], bins=bins_credit, labels=labels_credit, right=False)
    
    # Balance Tiers
    def get_balance_tier(val):
        if val == 0:
            return 'Zero Balance ($0)'
        elif val < 50000:
            return 'Low Balance (<$50K)'
        elif val < 100000:
            return 'Moderate Balance ($50K-$100K)'
        elif val < 150000:
            return 'High Balance ($100K-$150K)'
        else:
            return 'Ultra High Balance (>$150K)'
    df['BalanceTier'] = df['Balance'].apply(get_balance_tier)
    
    # Salary Tiers
    bins_sal = [0, 50000, 100000, 150000, 250000]
    labels_sal = ['<$50K', '$50K-$100K', '$100K-$150K', '>$150K']
    df['SalaryTier'] = pd.cut(df['EstimatedSalary'], bins=bins_sal, labels=labels_sal, right=False)
    
    out_path = os.path.join(OUTPUT_DIR, "Customers_Cleaned.csv")
    df.to_csv(out_path, index=False)
    print(f"Saved Customers_Cleaned.csv: {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def export_customer_predictions(df_cleaned):
    """Generates Customer_Churn_Predictions.csv using the trained ML champion model."""
    print("Generating Customer_Churn_Predictions.csv via Champion Model...")
    model_path = os.path.join(PROJECT_ROOT, "models", "best_model.pkl")
    if not os.path.exists(model_path):
        model_path = os.path.join(PROJECT_ROOT, "models", "random_forest.pkl")
    pipeline = joblib.load(model_path)
    
    # Generate probabilities and predictions
    probs = pipeline.predict_proba(df_cleaned)[:, 1]
    preds = pipeline.predict(df_cleaned)
    
    df_pred = df_cleaned.copy()
    df_pred['Churn_Probability'] = (probs * 100).round(2)
    df_pred['Churn_Probability_Decimal'] = probs.round(4)
    df_pred['Predicted_Churn'] = preds
    df_pred['Predicted_Churn_Label'] = np.where(preds == 1, 'Likely to Churn', 'Likely to Stay')
    
    # Risk categorization
    def assign_risk_category(p):
        if p >= 65.0:
            return 'High Risk'
        elif p >= 35.0:
            return 'Medium Risk'
        else:
            return 'Low Risk'
            
    df_pred['Risk_Category'] = df_pred['Churn_Probability'].apply(assign_risk_category)
    
    # Numerical Risk Sort Order for Power BI sorting
    risk_sort_map = {'High Risk': 1, 'Medium Risk': 2, 'Low Risk': 3}
    df_pred['Risk_Sort_Order'] = df_pred['Risk_Category'].map(risk_sort_map)
    
    # Recommended Action
    def assign_action(row):
        if row['Risk_Category'] == 'High Risk':
            if row['IsActiveMember'] == 0:
                return 'Urgent: VIP Re-activation campaign + Personal Call'
            elif row['NumOfProducts'] >= 3:
                return 'Urgent: Fee audit & product portfolio consolidation'
            elif row['Balance'] > 80000:
                return 'Urgent: Assign Premier Wealth Relationship Manager'
            else:
                return 'High Priority: Retention bonus & branch liaison check-in'
        elif row['Risk_Category'] == 'Medium Risk':
            if row['NumOfProducts'] == 1:
                return 'Medium Priority: Cross-sell secondary account with rewards'
            else:
                return 'Medium Priority: Send quarterly satisfaction survey & perks'
        else:
            return 'Standard: Loyalty maintenance & digital feature updates'
            
    df_pred['Recommended_Action'] = df_pred.apply(assign_action, axis=1)
    
    # Global Risk Rank (1 = highest churn probability)
    df_pred['Risk_Rank'] = df_pred['Churn_Probability'].rank(ascending=False, method='min').astype(int)
    
    out_path = os.path.join(OUTPUT_DIR, "Customer_Churn_Predictions.csv")
    df_pred.to_csv(out_path, index=False)
    print(f"Saved Customer_Churn_Predictions.csv: {df_pred.shape[0]} rows, {df_pred.shape[1]} columns")
    return df_pred


def export_model_evaluation():
    """Generates Model_Evaluation.csv, Confusion_Matrix_Data.csv, and ROC_Curve_Data.csv."""
    print("Generating Model Evaluation & ROC datasets...")
    meta_path = os.path.join(PROJECT_ROOT, "models", "model_metrics.json")
    with open(meta_path, "r") as f:
        meta = json.load(f)
        
    eval_results = meta['evaluation_results']
    best_model_name = meta['best_model_name']
    
    # 1. Model Summary Table
    model_rows = []
    cm_rows = []
    roc_rows = []
    
    for name, m in eval_results.items():
        cm = m['confusion_matrix']
        tn, fp = cm[0]
        fn, tp = cm[1]
        
        model_rows.append({
            'Model_Name': name,
            'Algorithm_Family': 'Ensemble' if 'Forest' in name or 'Boost' in name else ('Tree' if 'Tree' in name else 'Linear'),
            'Accuracy': round(m['accuracy'] * 100, 2),
            'Precision': round(m['precision'] * 100, 2),
            'Recall': round(m['recall'] * 100, 2),
            'F1_Score': round(m['f1_score'] * 100, 2),
            'ROC_AUC': round(m['roc_auc'], 4),
            'CV_AUC_Mean': round(m['cv_auc_mean'], 4),
            'CV_AUC_Std': round(m['cv_auc_std'], 4),
            'CV_F1_Mean': round(m['cv_f1_mean'], 4),
            'CV_F1_Std': round(m['cv_f1_std'], 4),
            'True_Negatives': tn,
            'False_Positives': fp,
            'False_Negatives': fn,
            'True_Positives': tp,
            'Is_Champion': 'Yes' if name == best_model_name else 'No'
        })
        
        # Confusion matrix records
        cm_rows.extend([
            {'Model_Name': name, 'Actual_Class': 'Retained (0)', 'Predicted_Class': 'Predicted Retained (0)', 'Count': tn, 'Type': 'True Negative'},
            {'Model_Name': name, 'Actual_Class': 'Retained (0)', 'Predicted_Class': 'Predicted Churned (1)', 'Count': fp, 'Type': 'False Positive (False Alarm)'},
            {'Model_Name': name, 'Actual_Class': 'Churned (1)', 'Predicted_Class': 'Predicted Retained (0)', 'Count': fn, 'Type': 'False Negative (Missed Churn)'},
            {'Model_Name': name, 'Actual_Class': 'Churned (1)', 'Predicted_Class': 'Predicted Churned (1)', 'Count': tp, 'Type': 'True Positive (Caught Churn)'}
        ])
        
        # ROC curve records
        roc = m['roc_curve']
        for i in range(len(roc['fpr'])):
            roc_rows.append({
                'Model_Name': name,
                'False_Positive_Rate': round(roc['fpr'][i], 4),
                'True_Positive_Rate': round(roc['tpr'][i], 4),
                'Threshold': round(roc['thresholds'][i], 4) if roc['thresholds'][i] <= 1.0 else 1.0
            })
            
    df_models = pd.DataFrame(model_rows).sort_values(by='ROC_AUC', ascending=False)
    df_models.to_csv(os.path.join(OUTPUT_DIR, "Model_Evaluation.csv"), index=False)
    print(f"Saved Model_Evaluation.csv: {len(df_models)} models")
    
    df_cm = pd.DataFrame(cm_rows)
    df_cm.to_csv(os.path.join(OUTPUT_DIR, "Confusion_Matrix_Data.csv"), index=False)
    print(f"Saved Confusion_Matrix_Data.csv: {len(df_cm)} rows")
    
    df_roc = pd.DataFrame(roc_rows)
    df_roc.to_csv(os.path.join(OUTPUT_DIR, "ROC_Curve_Data.csv"), index=False)
    print(f"Saved ROC_Curve_Data.csv: {len(df_roc)} points")


def export_feature_importance():
    """Generates Feature_Importance.csv across all trained models."""
    print("Generating Feature_Importance.csv...")
    importances = compute_feature_importances(os.path.join(PROJECT_ROOT, "models"))
    
    df_rf = importances['Random Forest'].set_index('Feature')
    df_gb = importances['Gradient Boosting'].set_index('Feature')
    df_lr = importances['Logistic Regression'].set_index('Feature')
    
    features = df_rf.index.tolist()
    combined_rows = []
    
    for f in features:
        combined_rows.append({
            'Feature': f,
            'Feature_Category': 'Demographic' if f in ['Age', 'Gender_Male', 'Geography_Germany', 'Geography_Spain'] else ('Financial' if f in ['CreditScore', 'Balance', 'EstimatedSalary'] else 'Behavioral'),
            'Random_Forest_Importance': round(df_rf.loc[f, 'Importance'], 4),
            'Random_Forest_Pct': round(df_rf.loc[f, 'Importance_Pct'], 2),
            'Gradient_Boosting_Importance': round(df_gb.loc[f, 'Importance'], 4) if f in df_gb.index else 0,
            'Gradient_Boosting_Pct': round(df_gb.loc[f, 'Importance_Pct'], 2) if f in df_gb.index else 0,
            'Logistic_Regression_Coef': round(df_lr.loc[f, 'Coefficient'], 4) if f in df_lr.index else 0,
            'Logistic_Regression_Odds_Ratio': round(df_lr.loc[f, 'Odds_Ratio'], 4) if f in df_lr.index else 1.0,
            'Predictive_Direction': 'Increases Churn' if df_lr.loc[f, 'Coefficient'] > 0 else 'Increases Retention'
        })
        
    df_fi = pd.DataFrame(combined_rows).sort_values(by='Random_Forest_Importance', ascending=False)
    df_fi['Rank'] = range(1, len(df_fi) + 1)
    
    out_path = os.path.join(OUTPUT_DIR, "Feature_Importance.csv")
    df_fi.to_csv(out_path, index=False)
    print(f"Saved Feature_Importance.csv: {len(df_fi)} features")


if __name__ == "__main__":
    df_c = export_cleaned_customers()
    export_customer_predictions(df_c)
    export_model_evaluation()
    export_feature_importance()
    print("ALL POWER BI DATASETS EXPORTED SUCCESSFULLY!")

