"""
Page 5: Individual Customer Churn Prediction & Retention Playbook.
Interactive form for real-time customer risk calculation, churn probability estimation,
risk driver decomposition, and personalized retention action strategies.
"""

import os
import sys
import json
import streamlit as st
import pandas as pd
import plotly.graph_objects as go

# Page config
st.set_page_config(page_title="Individual Prediction | ApexBank", page_icon="🎯", layout="wide")

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.ui_helpers import load_custom_css, render_header, render_sidebar
from src.prediction import (
    predict_single_customer,
    MODEL_FILES
)

load_custom_css()
render_sidebar()

render_header(
    title="Customer Risk Calculator & Retention Advisory",
    subtitle="Individual customer attrition scoring, probability gauge, risk classification, and tailored retention action playbook",
    badge_text="INTERACTIVE SCORER"
)

st.markdown("### 📝 Enter Customer Profile Attributes")
st.write("Input customer financial, demographic, and banking relationship information to evaluate real-time churn risk:")

# Two-column layout for customer input form
with st.form("customer_prediction_form"):
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 👤 Demographic & Relationship Profile")
        age = st.slider("Customer Age (Years)", min_value=18, max_value=92, value=42, help="Customer age in years. Empirically, ages 45-60 show higher attrition.")
        geography = st.selectbox("Geography / Country", ["France", "Germany", "Spain"], index=1, help="Bank jurisdiction of account origination.")
        gender = st.radio("Gender", ["Female", "Male"], index=0, horizontal=True)
        tenure = st.slider("Tenure with Bank (Years)", min_value=0, max_value=10, value=3, help="Number of years the customer has maintained an account with ApexBank.")
        is_active = st.radio("Active Membership Status", [1, 0], format_func=lambda x: "Active Member (Regular transactions)" if x == 1 else "Inactive Member (Dormant)", index=1)
        
    with col2:
        st.markdown("#### 💳 Financial & Product Engagement")
        credit_score = st.slider("Credit Score (FICO/Bureau)", min_value=350, max_value=850, value=630, help="Standard credit bureau rating.")
        balance = st.number_input("Current Account Balance ($)", min_value=0.0, max_value=300000.0, value=98000.0, step=1000.0, format="%.2f", help="Total deposit balance across checking and savings.")
        num_products = st.selectbox("Number of Bank Products Held", [1, 2, 3, 4], index=2, help="Accounts, loans, credit cards, mortgages held.")
        has_card = st.radio("ApexBank Credit Card Holder", [1, 0], format_func=lambda x: "Yes (Holds Credit Card)" if x == 1 else "No (No Credit Card)", index=0)
        salary = st.number_input("Estimated Annual Salary ($)", min_value=5000.0, max_value=250000.0, value=112000.0, step=2500.0, format="%.2f")

    st.markdown("---")
    st.markdown("#### 🤖 Model Selection")
    model_choice = st.selectbox(
        "Choose Inference Algorithm:",
        options=list(MODEL_FILES.keys()),
        index=0,
        help="Select which trained pipeline to use for generating predictions."
    )
    
    submitted = st.form_submit_button("⚡ Evaluate Customer Churn Risk", use_container_width=True)

# Process Prediction
if submitted or 'last_prediction' in st.session_state:
    if submitted:
        customer_dict = {
            'CreditScore': credit_score,
            'Geography': geography,
            'Gender': gender,
            'Age': age,
            'Tenure': tenure,
            'Balance': balance,
            'NumOfProducts': num_products,
            'HasCrCard': has_card,
            'IsActiveMember': is_active,
            'EstimatedSalary': salary
        }
        res = predict_single_customer(customer_dict, model_choice=model_choice, models_dir=os.path.join(PROJECT_ROOT, "models"))
        st.session_state['last_prediction'] = res
    else:
        res = st.session_state['last_prediction']

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("### 📊 Predictive Risk Assessment Result")
    
    res_col1, res_col2 = st.columns([1, 1])
    
    with res_col1:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">🎯 Attrition Risk Gauge</div>
        """, unsafe_allow_html=True)
        
        prob_pct = res['churn_probability_pct']
        risk_color = res['risk_color']
        
        # Interactive Gauge Chart
        fig_gauge = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=prob_pct,
            number={'suffix': "%", 'font': {'size': 38, 'color': '#0B192C'}},
            title={'text': f"<b>{res['prediction'].upper()}</b><br><span style='font-size:14px;color:{risk_color}'>Category: {res['risk_category']}</span>", 'font': {'size': 18}},
            gauge={
                'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#64748B"},
                'bar': {'color': risk_color, 'thickness': 0.28},
                'bgcolor': "white",
                'borderwidth': 1,
                'bordercolor': "#E2E8F0",
                'steps': [
                    {'range': [0, 35], 'color': '#D1FAE5'},
                    {'range': [35, 65], 'color': '#FEF3C7'},
                    {'range': [65, 100], 'color': '#FEE2E2'}
                ],
                'threshold': {
                    'line': {'color': "#EF4444", 'width': 3},
                    'thickness': 0.8,
                    'value': 65
                }
            }
        ))
        
        fig_gauge.update_layout(
            template="plotly_white",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=280,
            margin=dict(t=30, b=10, l=30, r=30)
        )
        st.plotly_chart(fig_gauge, use_container_width=True)
        
        st.markdown(f"""
        <div style="text-align:center; padding-bottom: 10px;">
            <span class="risk-badge {res['risk_class']}" style="font-size: 14px; padding: 8px 20px;">
                {res['risk_category']} ({prob_pct:.1f}% Probability)
            </span>
            <div style="font-size:12px; color:#64748B; margin-top:6px;">
                Evaluated by <b>{res['selected_model']}</b>
            </div>
        </div>
        </div>
        """, unsafe_allow_html=True)

    with res_col2:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">🔍 Key Contributing Risk Drivers</div>
        """, unsafe_allow_html=True)
        
        for driver in res['key_drivers']:
            st.markdown(f"""
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px; background:#F8FAFC; border:1px solid #E2E8F0; padding:10px 14px; border-radius:8px;">
                <span style="font-size:16px;">⚠️</span>
                <span style="font-size:13px; color:#1E293B; font-weight:500;">{driver}</span>
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown("</div>", unsafe_allow_html=True)

    # Actionable Retention Playbook
    st.markdown("### 🛡️ Recommended Customer Retention Playbook")
    st.write("Tailored interventions designed to mitigate attrition risk for this specific profile:")
    
    playbook_cols = st.columns(len(res['retention_playbook']))
    for idx, play in enumerate(res['retention_playbook']):
        with playbook_cols[idx]:
            st.markdown(f"""
            <div class="content-card" style="border-top: 4px solid #2563EB; min-height: 220px;">
                <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #2563EB; letter-spacing: 0.5px;">
                    Trigger #{idx+1}
                </div>
                <div style="font-size: 14px; font-weight: 800; color: #0B192C; margin: 4px 0 8px 0;">
                    {play['action']}
                </div>
                <div style="font-size: 12px; font-weight: 600; color: #64748B; margin-bottom: 6px;">
                    Context: {play['trigger']}
                </div>
                <p style="font-size: 12px; color: #475569; line-height: 1.5; margin: 0;">
                    {play['details']}
                </p>
            </div>
            """, unsafe_allow_html=True)

    # Download Prediction Record
    st.markdown("<br>", unsafe_allow_html=True)
    report_dict = {
        **res['customer_data'],
        'Prediction': res['prediction'],
        'Churn_Probability_Pct': res['churn_probability_pct'],
        'Risk_Category': res['risk_category'],
        'Evaluating_Model': res['selected_model']
    }
    df_single_report = pd.DataFrame([report_dict])
    csv_download = df_single_report.to_csv(index=False)
    
    st.download_button(
        label="📥 Download Individual Customer Risk Report (CSV)",
        data=csv_download,
        file_name=f"customer_risk_report_{res['risk_category'].replace(' ', '_').lower()}.csv",
        mime="text/csv",
        use_container_width=True
    )

