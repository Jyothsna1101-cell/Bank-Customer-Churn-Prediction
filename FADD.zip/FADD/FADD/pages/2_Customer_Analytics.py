"""
Page 2: Customer Analytics & Cohort Exploration.
Interactive multi-dimensional analysis across demographic, financial, and behavioral attributes
with real-time interactive slicing and filtering controls.
"""

import os
import sys
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Page config
st.set_page_config(page_title="Customer Analytics | ApexBank", page_icon="👥", layout="wide")

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.ui_helpers import load_custom_css, render_header, render_sidebar, get_current_dataset
from src.eda import (
    create_gender_vs_churn_chart,
    create_products_vs_churn_chart,
    create_balance_vs_churn_chart,
    create_activity_and_credit_card_chart,
    create_tenure_and_salary_chart
)

load_custom_css()
render_sidebar()

render_header(
    title="Customer Cohort Analytics & Demographic Slicing",
    subtitle="Exploratory multi-variable analysis across demographics, financial balances, product holdings, and activity",
    badge_text="INTERACTIVE SLICER"
)

# Load base data
df_raw = get_current_dataset()

# Filter Panel
st.markdown("### 🔍 Interactive Portfolio Filters")
with st.expander("Filter Customer Cohort (Click to Expand / Collapse)", expanded=True):
    fc1, fc2, fc3, fc4 = st.columns(4)
    
    with fc1:
        countries = df_raw['Geography'].unique().tolist() if 'Geography' in df_raw.columns else []
        selected_countries = st.multiselect("Geography / Country", options=countries, default=countries)
        
    with fc2:
        genders = df_raw['Gender'].unique().tolist() if 'Gender' in df_raw.columns else []
        selected_genders = st.multiselect("Customer Gender", options=genders, default=genders)
        
    with fc3:
        min_age, max_age = int(df_raw['Age'].min()), int(df_raw['Age'].max())
        selected_age = st.slider("Age Range", min_value=min_age, max_value=max_age, value=(min_age, max_age))
        
    with fc4:
        activity_option = st.selectbox("Activity Status", ["All Customers", "Active Members Only", "Inactive Members Only"])

# Apply Filters
filtered_df = df_raw.copy()

if selected_countries:
    filtered_df = filtered_df[filtered_df['Geography'].isin(selected_countries)]
if selected_genders:
    filtered_df = filtered_df[filtered_df['Gender'].isin(selected_genders)]
filtered_df = filtered_df[(filtered_df['Age'] >= selected_age[0]) & (filtered_df['Age'] <= selected_age[1])]

if activity_option == "Active Members Only":
    filtered_df = filtered_df[filtered_df['IsActiveMember'] == 1]
elif activity_option == "Inactive Members Only":
    filtered_df = filtered_df[filtered_df['IsActiveMember'] == 0]

# Filter Summary Bar
f_count = len(filtered_df)
if f_count == 0:
    st.warning("⚠️ No customers match the selected filter criteria. Please broaden your selection.")
    st.stop()

f_churn = filtered_df['Exited'].sum()
f_churn_rate = (f_churn / f_count * 100) if f_count > 0 else 0
f_balance = filtered_df['Balance'].sum()

mc1, mc2, mc3, mc4 = st.columns(4)
with mc1:
    st.metric("Filtered Customers", f"{f_count:,}", f"{(f_count/len(df_raw)*100):.1f}% of total")
with mc2:
    st.metric("Cohort Churn Rate", f"{f_churn_rate:.2f}%", f"{f_churn_rate - (df_raw['Exited'].mean()*100):+.2f}% vs benchmark", delta_color="inverse")
with mc3:
    st.metric("Cohort Deposit Pool", f"${f_balance/1e6:.2f}M", f"Avg: ${filtered_df['Balance'].mean():,.0f}")
with mc4:
    st.metric("Avg Credit Score", f"{filtered_df['CreditScore'].mean():.0f}", f"{filtered_df['CreditScore'].mean() - df_raw['CreditScore'].mean():+.0f} pts")

st.markdown("<br>", unsafe_allow_html=True)

# Tabs for Sectioned Deep Dives
tab_demographics, tab_financial, tab_behavior = st.tabs([
    "👤 1. Demographic Analysis", 
    "💳 2. Financial & Balance Distribution", 
    "📈 3. Behavioral & Product Engagement"
])

# TAB 1: DEMOGRAPHICS
with tab_demographics:
    d_col1, d_col2 = st.columns(2)
    with d_col1:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">👥 Gender Disparity in Attrition</div>
        """, unsafe_allow_html=True)
        fig_gender, insight_gender = create_gender_vs_churn_chart(filtered_df)
        st.plotly_chart(fig_gender, use_container_width=True)
        st.markdown(f"""
        <div class="callout-box callout-info">{insight_gender}</div>
        </div>
        """, unsafe_allow_html=True)
        
    with d_col2:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">📊 Age Pyramid by Attrition</div>
        """, unsafe_allow_html=True)
        fig_age_hist = px.histogram(
            filtered_df, x="Age", color="Exited",
            color_discrete_map={0: "#10B981", 1: "#EF4444"},
            barmode="overlay", nbins=30,
            labels={'Exited': 'Status', 'count': 'Customers'},
            title="<b>Age Distribution Histogram</b>"
        )
        fig_age_hist.for_each_trace(lambda t: t.update(name="Retained" if t.name == "0" else "Churned"))
        fig_age_hist.update_layout(template="plotly_white", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig_age_hist, use_container_width=True)
        st.markdown("""
        <div class="callout-box callout-warning">
            The churned distribution shifts heavily rightward, peaking between ages 45 and 55, while retained customers cluster tightly in their early-to-mid 30s.
        </div>
        </div>
        """, unsafe_allow_html=True)

# TAB 2: FINANCIAL
with tab_financial:
    f_col1, f_col2 = st.columns(2)
    with f_col1:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">💰 Balance Breakdown & Zero-Balance Phenomenon</div>
        """, unsafe_allow_html=True)
        fig_bal, insight_bal = create_balance_vs_churn_chart(filtered_df)
        st.plotly_chart(fig_bal, use_container_width=True)
        st.markdown(f"""
        <div class="callout-box callout-danger">{insight_bal}</div>
        </div>
        """, unsafe_allow_html=True)
        
    with f_col2:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">💳 Credit Score vs Account Balance Scatter</div>
        """, unsafe_allow_html=True)
        # Sample for fast responsive plotting if filtered_df is large
        plot_sample = filtered_df.sample(min(1500, len(filtered_df)), random_state=42)
        fig_scatter = px.scatter(
            plot_sample, x="CreditScore", y="Balance", color="Exited",
            color_discrete_map={0: "#10B981", 1: "#EF4444"},
            labels={'Exited': 'Customer Status'},
            opacity=0.6,
            hover_data=['Geography', 'Age', 'NumOfProducts'],
            title="<b>Credit Score vs Account Balance ($)</b>"
        )
        fig_scatter.for_each_trace(lambda t: t.update(name="Retained" if t.name == "0" else "Churned"))
        fig_scatter.update_layout(template="plotly_white", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig_scatter, use_container_width=True)
        st.markdown("""
        <div class="callout-box callout-info">
            Credit score alone has low correlation with churn, demonstrating that creditworthy affluent customers churn just as frequently as low-credit customers when service falls short.
        </div>
        </div>
        """, unsafe_allow_html=True)

# TAB 3: BEHAVIORAL
with tab_behavior:
    b_col1, b_col2 = st.columns(2)
    with b_col1:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">📦 Product Portfolio Size & Churn Spike</div>
        """, unsafe_allow_html=True)
        fig_prod, insight_prod = create_products_vs_churn_chart(filtered_df)
        st.plotly_chart(fig_prod, use_container_width=True)
        st.markdown(f"""
        <div class="callout-box callout-danger">{insight_prod}</div>
        </div>
        """, unsafe_allow_html=True)
        
    with b_col2:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">⚡ Activity Status & Credit Card Engagement</div>
        """, unsafe_allow_html=True)
        fig_act, insight_act = create_activity_and_credit_card_chart(filtered_df)
        st.plotly_chart(fig_act, use_container_width=True)
        st.markdown(f"""
        <div class="callout-box callout-success">{insight_act}</div>
        </div>
        """, unsafe_allow_html=True)
        
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">⏳ Tenure & Salary Correlation</div>
    """, unsafe_allow_html=True)
    fig_tenure, insight_tenure = create_tenure_and_salary_chart(filtered_df)
    st.plotly_chart(fig_tenure, use_container_width=True)
    st.markdown(f"""
    <div class="callout-box callout-info">{insight_tenure}</div>
    </div>
    """, unsafe_allow_html=True)

