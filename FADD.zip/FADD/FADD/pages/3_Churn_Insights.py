"""
Page 3: Churn Insights & Machine Learning Explainability.
Identifies the top predictive drivers of customer attrition using Random Forest MDI,
Gradient Boosting MDI, and Logistic Regression coefficients, with causal vs predictive distinctions.
"""

import os
import sys
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Page config
st.set_page_config(page_title="Churn Insights | ApexBank", page_icon="💡", layout="wide")

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.ui_helpers import load_custom_css, render_header, render_sidebar, get_current_dataset
from src.eda import create_correlation_heatmap
from src.feature_importance import (
    compute_feature_importances,
    create_feature_importance_chart,
    create_logistic_coefficients_chart,
    get_causality_caveat_text
)

load_custom_css()
render_sidebar()

render_header(
    title="Churn Insights & Feature Explainability",
    subtitle="Algorithmic feature ranking, econometric log-odds coefficients, and behavioral attrition drivers",
    badge_text="MODEL EXPLAINABILITY"
)

# Load dataset & importances
df = get_current_dataset()

try:
    importances_dict = compute_feature_importances(os.path.join(PROJECT_ROOT, "models"))
except Exception as e:
    st.error(f"Error computing feature importances: {e}. Please ensure models are trained.")
    st.stop()

# Top Influential Drivers Summary
st.markdown("### 🏆 Top Predictive Factors of Customer Attrition")

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown("""
    <div class="kpi-card kpi-danger">
        <div class="kpi-label">#1 Predictive Driver</div>
        <div class="kpi-value" style="font-size:22px;">Customer Age</div>
        <div class="kpi-delta negative">Surges 56% at 50-60 Yrs</div>
    </div>
    """, unsafe_allow_html=True)

with c2:
    st.markdown("""
    <div class="kpi-card kpi-warning">
        <div class="kpi-label">#2 Predictive Driver</div>
        <div class="kpi-value" style="font-size:22px;">NumOfProducts</div>
        <div class="kpi-delta negative">82-100% Churn with 3+ Products</div>
    </div>
    """, unsafe_allow_html=True)

with c3:
    st.markdown("""
    <div class="kpi-card kpi-info">
        <div class="kpi-label">#3 Predictive Driver</div>
        <div class="kpi-value" style="font-size:22px;">Geography: Germany</div>
        <div class="kpi-delta negative">2x National Churn Rate</div>
    </div>
    """, unsafe_allow_html=True)

with c4:
    st.markdown("""
    <div class="kpi-card kpi-success">
        <div class="kpi-label">#1 Retention Buffer</div>
        <div class="kpi-value" style="font-size:22px;">Active Member</div>
        <div class="kpi-delta positive">Cuts Attrition by ~47%</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Feature Importance Tabs
tab_rf, tab_gb, tab_lr, tab_corr = st.tabs([
    "🌲 Random Forest Importance",
    "🚀 Gradient Boosting Importance",
    "📈 Logistic Regression Odds Ratios",
    "🔥 Correlation Matrix"
])

with tab_rf:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">🌲 Random Forest Mean Decrease in Impurity (MDI)</div>
    """, unsafe_allow_html=True)
    df_rf = importances_dict['Random Forest']
    fig_rf = create_feature_importance_chart(df_rf, "Random Forest")
    st.plotly_chart(fig_rf, use_container_width=True)
    st.markdown("""
    <div class="callout-box callout-info">
        <b>Random Forest Ranking:</b> <code>Age</code> accounts for the largest fraction of split purity improvement (over 23%), 
        followed by <code>NumOfProducts</code> (~16%) and <code>EstimatedSalary</code> / <code>CreditScore</code>.
    </div>
    </div>
    """, unsafe_allow_html=True)
    with st.expander("View Numerical Importance Table (Random Forest)"):
        st.dataframe(df_rf, use_container_width=True)

with tab_gb:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">🚀 Gradient Boosting Relative Tree Importance</div>
    """, unsafe_allow_html=True)
    df_gb = importances_dict['Gradient Boosting']
    fig_gb = create_feature_importance_chart(df_gb, "Gradient Boosting")
    st.plotly_chart(fig_gb, use_container_width=True)
    st.markdown("""
    <div class="callout-box callout-info">
        <b>Gradient Boosting Ranking:</b> Sequentially boosted trees place overwhelming weight on <code>Age</code> (~38%) and 
        <code>NumOfProducts</code> (~32%), showing that non-linear interaction between age and product count accounts for the majority of predictive power.
    </div>
    </div>
    """, unsafe_allow_html=True)
    with st.expander("View Numerical Importance Table (Gradient Boosting)"):
        st.dataframe(df_gb, use_container_width=True)

with tab_lr:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">📈 Logistic Regression Log-Odds & Odds Ratios</div>
    """, unsafe_allow_html=True)
    df_lr = importances_dict['Logistic Regression']
    fig_lr = create_logistic_coefficients_chart(df_lr)
    st.plotly_chart(fig_lr, use_container_width=True)
    st.markdown("""
    <div class="callout-box callout-warning">
        <b>Econometric Interpretation:</b> Positive coefficients (Red) push customer odds toward churn; negative coefficients (Green) increase retention.
        Specifically, being an <b>Active Member (Odds Ratio ~0.46) reduces odds of churn by over 50%</b>, while being in <b>Germany (Odds Ratio ~1.95) nearly doubles churn odds</b> compared to France.
    </div>
    </div>
    """, unsafe_allow_html=True)
    with st.expander("View Logistic Regression Coefficients Table"):
        st.dataframe(df_lr[['Feature', 'Coefficient', 'Odds_Ratio']], use_container_width=True)

with tab_corr:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">🔥 Numerical Feature Correlation Heatmap</div>
    """, unsafe_allow_html=True)
    fig_corr, insight_corr = create_correlation_heatmap(df)
    st.plotly_chart(fig_corr, use_container_width=True)
    st.markdown(f"""
    <div class="callout-box callout-info">{insight_corr}</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# High-Risk Customer Behavioral Personas
st.markdown("### 🎭 High-Risk Customer Archetypes & Personas")

p1, p2, p3 = st.columns(3)

with p1:
    st.markdown("""
    <div class="content-card" style="border-top: 4px solid #EF4444;">
        <div style="font-weight: 800; font-size: 16px; color: #0B192C;">Persona A: The Affluent German Exiter</div>
        <div style="font-size: 12px; color: #DC2626; font-weight: 700; margin-bottom: 8px;">RISK: EXTREME (Probability > 85%)</div>
        <p style="font-size: 13px; color: #475569; line-height: 1.5;">
            <b>Profile:</b> Age 48-62, residing in Germany, Balance > $110,000, 1 or 3 products, Inactive member.<br>
            <b>Driver:</b> High fees or dissatisfaction with branch advisory services, competitor fintech migration.<br>
            <b>Loss Impact:</b> Severe deposit outflow ($100K+ per account).
        </p>
    </div>
    """, unsafe_allow_html=True)

with p2:
    st.markdown("""
    <div class="content-card" style="border-top: 4px solid #F59E0B;">
        <div style="font-weight: 800; font-size: 16px; color: #0B192C;">Persona B: The Over-Bundled Customer</div>
        <div style="font-size: 12px; color: #D97706; font-weight: 700; margin-bottom: 8px;">RISK: HIGH (Probability ~ 80%)</div>
        <p style="font-size: 13px; color: #475569; line-height: 1.5;">
            <b>Profile:</b> Any age or country, holding 3 or 4 bank products (loans, credit card, investment account).<br>
            <b>Driver:</b> Cross-sell fatigue, hidden administrative fees, disjointed multi-product communications.<br>
            <b>Loss Impact:</b> Complete relationship defection.
        </p>
    </div>
    """, unsafe_allow_html=True)

with p3:
    st.markdown("""
    <div class="content-card" style="border-top: 4px solid #2563EB;">
        <div style="font-weight: 800; font-size: 16px; color: #0B192C;">Persona C: The Disengaged Single-Product</div>
        <div style="font-size: 12px; color: #2563EB; font-weight: 700; margin-bottom: 8px;">RISK: MODERATE (Probability ~ 40-55%)</div>
        <p style="font-size: 13px; color: #475569; line-height: 1.5;">
            <b>Profile:</b> Inactive status, holding only 1 product, low or zero balance, credit card holder.<br>
            <b>Driver:</b> Lack of daily banking utility, inertia until annual fee or account review.<br>
            <b>Loss Impact:</b> Low capital loss, high attrition volume.
        </p>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Methodology Note on Causation vs Correlation
st.markdown("""
<div class="content-card" style="background: #F8FAFC; border-left: 4px solid #0B192C;">
""", unsafe_allow_html=True)
st.markdown(get_causality_caveat_text())
st.markdown("</div>", unsafe_allow_html=True)

