"""
Page 1: Executive Overview Dashboard.
Provides high-level banking KPIs, customer attrition rates, portfolio financial exposure,
and macro churn distributions for senior management decision-making.
"""

import os
import sys
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Set page config
st.set_page_config(page_title="Executive Overview | ApexBank", page_icon="📊", layout="wide")

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.ui_helpers import load_custom_css, render_header, render_sidebar, get_current_dataset
from src.data_preprocessing import get_data_summary
from src.eda import (
    create_churn_distribution_chart,
    create_geography_vs_churn_chart,
    create_age_vs_churn_chart
)

load_custom_css()
render_sidebar()

render_header(
    title="Executive Overview & Portfolio Health",
    subtitle="High-level customer attrition indicators, deposit exposure, and demographic distribution metrics",
    badge_text="EXECUTIVE DASHBOARD"
)

# Load data
df = get_current_dataset()
summary = get_data_summary(df)

# Financial Calculations
total_balance = df['Balance'].sum() if 'Balance' in df.columns else 0
churned_df = df[df['Exited'] == 1]
retained_df = df[df['Exited'] == 0]

churned_balance = churned_df['Balance'].sum()
retained_balance = retained_df['Balance'].sum()
avg_churned_balance = churned_df['Balance'].mean()
avg_retained_balance = retained_df['Balance'].mean()

# Executive KPI Grid
c1, c2, c3, c4 = st.columns(4)

with c1:
    st.markdown(f"""
    <div class="kpi-card kpi-info">
        <div class="kpi-label">Total Verified Accounts</div>
        <div class="kpi-value">{summary['total_rows']:,}</div>
        <div class="kpi-delta neutral">100% Benchmarked Records</div>
    </div>
    """, unsafe_allow_html=True)

with c2:
    st.markdown(f"""
    <div class="kpi-card kpi-danger">
        <div class="kpi-label">Total Churned Customers</div>
        <div class="kpi-value">{summary['churn_count']:,}</div>
        <div class="kpi-delta negative">Attrition Rate: {summary['churn_rate']:.2f}%</div>
    </div>
    """, unsafe_allow_html=True)

with c3:
    st.markdown(f"""
    <div class="kpi-card kpi-success">
        <div class="kpi-label">Retained Customer Base</div>
        <div class="kpi-value">{summary['retained_count']:,}</div>
        <div class="kpi-delta positive">Retention Rate: {100 - summary['churn_rate']:.2f}%</div>
    </div>
    """, unsafe_allow_html=True)

with c4:
    st.markdown(f"""
    <div class="kpi-card kpi-warning">
        <div class="kpi-label">Deposit Capital at Risk</div>
        <div class="kpi-value">${churned_balance/1e6:.2f}M</div>
        <div class="kpi-delta negative">{(churned_balance/total_balance*100):.1f}% of Total Portfolio Balance</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Secondary Metric Row
s1, s2, s3, s4 = st.columns(4)
with s1:
    st.metric(label="Average Customer Age", value=f"{summary['avg_age']:.1f} Yrs", delta=f"{churned_df['Age'].mean() - retained_df['Age'].mean():+.1f} Yrs (Churned vs Retained)", delta_color="inverse")
with s2:
    st.metric(label="Avg Balance (Churned)", value=f"${avg_churned_balance:,.0f}", delta=f"${avg_churned_balance - avg_retained_balance:+,.0f} vs Retained", delta_color="inverse")
with s3:
    st.metric(label="Active Member Share", value=f"{(df['IsActiveMember'].mean()*100):.1f}%", delta="-12.5% Inactive Churn Penalty", delta_color="normal")
with s4:
    st.metric(label="Average Credit Score", value=f"{summary['avg_credit_score']:.0f}", delta=f"{churned_df['CreditScore'].mean() - retained_df['CreditScore'].mean():+.0f} pts", delta_color="off")

st.markdown("<br>", unsafe_allow_html=True)

# Visualizations Row 1: Donut Chart & Geographic Breakdown
col1, col2 = st.columns([1, 1])

with col1:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">📊 Customer Attrition Proportion</div>
    """, unsafe_allow_html=True)
    fig_donut, insight_donut = create_churn_distribution_chart(df)
    st.plotly_chart(fig_donut, use_container_width=True)
    st.markdown(f"""
    <div class="callout-box callout-info">
        {insight_donut}
    </div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">🌍 Geographic Retention & Exposure</div>
    """, unsafe_allow_html=True)
    fig_geo, insight_geo = create_geography_vs_churn_chart(df)
    st.plotly_chart(fig_geo, use_container_width=True)
    st.markdown(f"""
    <div class="callout-box callout-danger">
        {insight_geo}
    </div>
    </div>
    """, unsafe_allow_html=True)

# Visualizations Row 2: Demographic Age Distribution
st.markdown("""
<div class="content-card">
    <div class="content-card-header">👥 Age Demographics & Lifecycle Attrition Vulnerability</div>
""", unsafe_allow_html=True)
fig_age, insight_age = create_age_vs_churn_chart(df)
st.plotly_chart(fig_age, use_container_width=True)
st.markdown(f"""
<div class="callout-box callout-warning">
    {insight_age}
</div>
</div>
""", unsafe_allow_html=True)

# Executive Strategy Summary Card
st.markdown("""
<div class="content-card">
    <div class="content-card-header">🎯 Executive Strategic Recommendations</div>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-top: 10px;">
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 16px;">
            <div style="font-weight: 700; color: #0B192C; margin-bottom: 6px;">1. Protect High-Balance German Accounts</div>
            <p style="font-size: 13px; color: #475569; margin: 0;">
                German customers represent <b>over 39% of total churned balances</b> despite being only 25% of customers. Establish an immediate executive retention taskforce for high-deposit German accounts.
            </p>
        </div>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 16px;">
            <div style="font-weight: 700; color: #0B192C; margin-bottom: 6px;">2. Intervene at Ages 45-60</div>
            <p style="font-size: 13px; color: #475569; margin: 0;">
                Attrition surges to <b>56% in the 50-60 age bracket</b>. Deliver specialized retirement planning, wealth succession advisory, and dedicated senior branch liaisons.
            </p>
        </div>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 16px;">
            <div style="font-weight: 700; color: #0B192C; margin-bottom: 6px;">3. Audit Multi-Product Bundles</div>
            <p style="font-size: 13px; color: #475569; margin: 0;">
                Customers with 3 or 4 products defect at 80%-100% rates. Eliminate confusing multiple maintenance fees and streamline bundled account servicing.
            </p>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

