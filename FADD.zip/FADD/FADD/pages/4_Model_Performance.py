"""
Page 4: Machine Learning Model Performance & Evaluation.
Comparative analysis of Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting.
Interactive ROC curves, confusion matrices, classification reports, and selection methodology.
"""

import os
import sys
import streamlit as st
import pandas as pd
import plotly.graph_objects as go

# Page config
st.set_page_config(page_title="Model Performance | ApexBank", page_icon="⚙️", layout="wide")

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.ui_helpers import load_custom_css, render_header, render_sidebar
from src.evaluate_models import (
    load_evaluation_metadata,
    get_comparison_dataframe,
    create_model_comparison_chart,
    create_roc_curves_chart,
    create_confusion_matrix_heatmap,
    get_classification_report_table
)

load_custom_css()
render_sidebar()

render_header(
    title="Machine Learning Model Evaluation & Leaderboard",
    subtitle="Rigorous cross-validation, holdout test metrics, ROC analysis, and confusion matrices across 4 algorithms",
    badge_text="RIGOROUS BENCHMARK"
)

# Load metadata
try:
    metadata = load_evaluation_metadata(os.path.join(PROJECT_ROOT, "models"))
except Exception as e:
    st.error(f"Error loading model metrics: {e}. Please ensure models are trained via `python src/train_models.py`.")
    st.stop()

# Champion Model Callout Banner
best_model = metadata.get('best_model_name', 'Random Forest')
eval_results = metadata.get('evaluation_results', {})
best_m = eval_results.get(best_model, {})

st.markdown(f"""
<div class="callout-box callout-success" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
    <div>
        <span style="font-size:16px; font-weight:800;">🏆 Designated Production Champion: {best_model}</span><br>
        <span style="font-size:13px;">Selected via harmonic objective: <b>50% ROC-AUC ({best_m.get('roc_auc', 0):.4f}) + 50% F1-Score ({best_m.get('f1_score', 0)*100:.1f}%)</b> to maximize customer attrition capture while managing outreach volume.</span>
    </div>
    <div>
        <span class="risk-badge low" style="font-size:12px;">TEST ACCURACY: {best_m.get('accuracy', 0)*100:.1f}%</span>
        <span class="risk-badge high" style="font-size:12px; margin-left: 6px;">RECALL: {best_m.get('recall', 0)*100:.1f}%</span>
    </div>
</div>
""", unsafe_allow_html=True)

# Section 1: Comparative Table
st.markdown("### 📊 Model Benchmark Leaderboard (Holdout Test Set)")
df_comp = get_comparison_dataframe(metadata)

# Style comparison table
st.dataframe(
    df_comp.style.format({
        'Accuracy': '{:.2f}%',
        'Precision': '{:.2f}%',
        'Recall': '{:.2f}%',
        'F1-Score': '{:.2f}%',
        'ROC-AUC': '{:.4f}'
    }).highlight_max(subset=['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC'], color='#D1FAE5'),
    use_container_width=True
)

st.markdown("<br>", unsafe_allow_html=True)

# Section 2: Visual Comparison (Grouped Bar & ROC Curves)
col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">📊 Multi-Metric Model Comparison</div>
    """, unsafe_allow_html=True)
    fig_bar = create_model_comparison_chart(metadata)
    st.plotly_chart(fig_bar, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="content-card">
        <div class="content-card-header">📈 Comparative ROC Curves</div>
    """, unsafe_allow_html=True)
    fig_roc = create_roc_curves_chart(metadata)
    st.plotly_chart(fig_roc, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Section 3: In-Depth Diagnostic (Confusion Matrix & Classification Report)
st.markdown("### 🔬 Model Diagnostic & Error Analysis")

selected_model = st.selectbox(
    "Select Model for Detailed Diagnostic:",
    options=list(eval_results.keys()),
    index=list(eval_results.keys()).index(best_model) if best_model in eval_results else 0
)

col_cm, col_cr = st.columns([1, 1])

with col_cm:
    st.markdown(f"""
    <div class="content-card">
        <div class="content-card-header">🎯 Confusion Matrix ({selected_model})</div>
    """, unsafe_allow_html=True)
    fig_cm = create_confusion_matrix_heatmap(metadata, selected_model)
    st.plotly_chart(fig_cm, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

with col_cr:
    st.markdown(f"""
    <div class="content-card">
        <div class="content-card-header">📋 Classification Report ({selected_model})</div>
    """, unsafe_allow_html=True)
    df_cr = get_classification_report_table(metadata, selected_model)
    st.dataframe(df_cr, use_container_width=True, hide_index=True)
    
    # Contextual metric callout
    m = eval_results[selected_model]
    cm = m['confusion_matrix']
    tn, fp = cm[0]
    fn, tp = cm[1]
    
    st.markdown(f"""
    <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:8px; padding:12px; font-size:13px; line-height:1.6; margin-top:10px;">
        • <b>True Positives (Caught Churners):</b> {tp:,} accounts protected.<br>
        • <b>False Negatives (Missed Churners):</b> {fn:,} accounts slipped through unaddressed.<br>
        • <b>False Positives (False Alarms):</b> {fp:,} loyal customers contacted for check-in.<br>
        • <b>True Negatives (Correctly Retained):</b> {tn:,} stable accounts.
    </div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Section 4: Evaluation Strategy Justification
with st.expander("📚 Why Accuracy is Insufficient: The Banking Attrition Evaluation Strategy", expanded=True):
    st.markdown("""
    ### ⚖️ The Economic Cost of Classification Errors in Banking
    
    In consumer banking customer churn, classes are inherently skewed (~80% retained vs ~20% churned). 
    Evaluating models solely on **Accuracy** introduces severe systemic blind spots:
    
    1. **The Naive Zero-Rule Baseline Fallacy**:
       A dummy model that blindly predicts "No Churn" for every customer will achieve **79.6% Accuracy**, yet has **0% Recall and 0% ROC-AUC**. 
       Such a model fails 100% of the bank's business objective while superficially appearing accurate.
       
    2. **The Asymmetric Loss Matrix**:
       - **Cost of a False Negative ($C_{FN}$)**: A defecting customer with an average deposit of $70,000–$100,000 leaves permanently, forfeiting net interest margin (NIM) and customer lifetime value (LTV).
       - **Cost of a False Positive ($C_{FP}$)**: A retained customer is contacted with an appreciation call, reward voucher, or relationship check-in ($10–$25 outreach cost).
       - *Ratio*: $C_{FN} \\gg C_{FP}$ (by a factor of ~100x).
       
    3. **Why Random Forest is the Champion**:
       - **Gradient Boosting** achieves the highest raw accuracy (86.9%) and ROC-AUC (0.8676), but has low recall (~49.6%), missing half of all defectors.
       - **Decision Tree** achieves high recall (76.9%), but produces lower precision (45.0%) and lower ROC-AUC (0.8398).
       - **Random Forest** hits the strategic sweet spot: **ROC-AUC of 0.8658**, **Recall of 69.8%**, and **F1-Score of 63.5%**, capturing over 7 out of 10 churning customers while keeping false alarms controlled.
    """)

