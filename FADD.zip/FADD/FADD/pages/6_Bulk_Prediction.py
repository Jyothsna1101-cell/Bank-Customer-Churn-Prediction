"""
Page 6: Bulk Customer Attrition Risk Analysis & Batch Scoring.
Upload customer CSV files for high-throughput batch scoring, automated risk tier triage,
financial deposit exposure calculation, and enriched downloadable retention action reports.
"""

import os
import sys
import io
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Page config
st.set_page_config(page_title="Bulk Risk Analysis | ApexBank", page_icon="📁", layout="wide")

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.ui_helpers import load_custom_css, render_header, render_sidebar
from src.prediction import (
    predict_bulk_customers,
    generate_sample_csv,
    MODEL_FILES
)

load_custom_css()
render_sidebar()

render_header(
    title="Bulk Customer Risk Scoring & Batch Triage",
    subtitle="Enterprise batch scoring engine: ingest multi-record customer cohorts, prioritize high-risk accounts, and export retention plans",
    badge_text="BATCH INFERENCE ENGINE"
)

# Template Download & Ingestion Section
st.markdown("### 📥 1. Batch Dataset Ingestion")

upload_col1, upload_col2 = st.columns([2, 1])

with upload_col1:
    uploaded_file = st.file_uploader(
        "Upload Customer Batch File (CSV):",
        type=['csv'],
        help="Upload CSV containing customer profiles with standard Kaggle Churn Modelling columns."
    )

with upload_col2:
    st.markdown("""
    <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:10px; padding:16px;">
        <div style="font-weight:700; color:#0B192C; font-size:13px; margin-bottom:6px;">Need a Test Template?</div>
        <p style="font-size:12px; color:#475569; margin-bottom:12px;">
            Download our verified 25-customer sample file ready for immediate evaluation:
        </p>
    """, unsafe_allow_html=True)
    sample_csv_data = generate_sample_csv(25)
    st.download_button(
        label="📄 Download Sample Batch CSV",
        data=sample_csv_data,
        file_name="ApexBank_Sample_Customer_Batch.csv",
        mime="text/csv",
        use_container_width=True
    )
    
    if st.button("🚀 Load Sample Batch Directly", use_container_width=True):
        st.session_state['bulk_input_df'] = pd.read_csv(io.StringIO(sample_csv_data))
        st.success("Sample batch loaded into memory!")
    st.markdown("</div>", unsafe_allow_html=True)

# Select Model for batch scoring
st.markdown("---")
sc1, sc2 = st.columns([2, 1])
with sc1:
    selected_batch_model = st.selectbox(
        "Select Scoring Machine Learning Model:",
        options=list(MODEL_FILES.keys()),
        index=0
    )
with sc2:
    risk_threshold = st.slider("High-Risk Cutoff Probability (%)", min_value=50, max_value=85, value=65, step=5)

# Determine DataFrame to score
df_to_score = None
if uploaded_file is not None:
    try:
        df_to_score = pd.read_csv(uploaded_file)
    except Exception as e:
        st.error(f"Error reading uploaded CSV: {e}")
elif 'bulk_input_df' in st.session_state:
    df_to_score = st.session_state['bulk_input_df']

if df_to_score is not None:
    st.markdown(f"#### 🔍 Ingested Cohort Preview ({len(df_to_score):,} Records)")
    st.dataframe(df_to_score.head(5), use_container_width=True)
    
    if st.button("⚡ Execute Bulk Risk Scoring", type="primary", use_container_width=True):
        with st.spinner("Scoring customer records through machine learning pipeline..."):
            try:
                scored_df, summary = predict_bulk_customers(
                    df_to_score,
                    model_choice=selected_batch_model,
                    models_dir=os.path.join(PROJECT_ROOT, "models")
                )
                st.session_state['last_scored_df'] = scored_df
                st.session_state['last_scored_summary'] = summary
                st.success("Batch scoring completed successfully!")
            except Exception as e:
                st.error(f"Bulk scoring failed: {e}")

# Display Batch Results
if 'last_scored_df' in st.session_state:
    scored_df = st.session_state['last_scored_df']
    summary = st.session_state['last_scored_summary']
    
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("### 📊 Batch Evaluation Summary & Portfolio Triage")
    
    # KPI Grid
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(f"""
        <div class="kpi-card kpi-info">
            <div class="kpi-label">Accounts Evaluated</div>
            <div class="kpi-value">{summary['total_evaluated']:,}</div>
            <div class="kpi-delta neutral">100% Successfully Scored</div>
        </div>
        """, unsafe_allow_html=True)
        
    with k2:
        st.markdown(f"""
        <div class="kpi-card kpi-danger">
            <div class="kpi-label">High-Risk Accounts</div>
            <div class="kpi-value">{summary['high_risk_count']:,}</div>
            <div class="kpi-delta negative">{(summary['high_risk_count']/summary['total_evaluated']*100):.1f}% Urgent Attrition Danger</div>
        </div>
        """, unsafe_allow_html=True)
        
    with k3:
        st.markdown(f"""
        <div class="kpi-card kpi-warning">
            <div class="kpi-label">High-Risk Balance at Stake</div>
            <div class="kpi-value">${summary['high_risk_balance_at_risk']/1e3:,.1f}K</div>
            <div class="kpi-delta negative">Immediate Capital Exposure</div>
        </div>
        """, unsafe_allow_html=True)
        
    with k4:
        st.markdown(f"""
        <div class="kpi-card kpi-success">
            <div class="kpi-label">Mean Churn Probability</div>
            <div class="kpi-value">{summary['avg_churn_prob']:.1f}%</div>
            <div class="kpi-delta neutral">Cohort Average</div>
        </div>
        """, unsafe_allow_html=True)
        
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Batch Visualizations
    v_col1, v_col2 = st.columns(2)
    
    with v_col1:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">🎯 Risk Tier Distribution</div>
        """, unsafe_allow_html=True)
        tier_counts = scored_df['Risk_Tier'].value_counts().reset_index()
        tier_counts.columns = ['Risk_Tier', 'Count']
        
        color_map = {
            'High Risk': '#EF4444',
            'Medium Risk': '#F59E0B',
            'Low Risk': '#10B981'
        }
        
        fig_pie = px.pie(
            tier_counts,
            names='Risk_Tier',
            values='Count',
            color='Risk_Tier',
            color_discrete_map=color_map,
            hole=0.5,
            title="<b>Customer Portfolio Breakdown by Risk Tier</b>"
        )
        fig_pie.update_layout(template="plotly_white", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig_pie, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)
        
    with v_col2:
        st.markdown("""
        <div class="content-card">
            <div class="content-card-header">📈 Churn Probability Histogram</div>
        """, unsafe_allow_html=True)
        fig_hist = px.histogram(
            scored_df,
            x='Churn_Probability',
            nbins=20,
            color='Risk_Tier',
            color_discrete_map=color_map,
            title="<b>Distribution of Predicted Churn Probabilities</b>"
        )
        fig_hist.update_layout(
            template="plotly_white",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Predicted Churn Probability (%)",
            yaxis_title="Customer Count"
        )
        st.plotly_chart(fig_hist, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    # Scored Data Filter & Table
    st.markdown("### 📋 Prioritized Customer Risk Registry")
    
    tier_filter = st.multiselect(
        "Filter Registry by Risk Tier:",
        options=['High Risk', 'Medium Risk', 'Low Risk'],
        default=['High Risk', 'Medium Risk', 'Low Risk']
    )
    
    display_df = scored_df[scored_df['Risk_Tier'].isin(tier_filter)]
    
    # Format currency and percentages for clean presentation
    st.dataframe(
        display_df[[
            'CustomerId' if 'CustomerId' in display_df.columns else display_df.columns[0],
            'Surname' if 'Surname' in display_df.columns else display_df.columns[1],
            'CreditScore', 'Geography', 'Gender', 'Age', 'Balance', 'NumOfProducts',
            'IsActiveMember', 'Churn_Probability', 'Prediction', 'Risk_Tier', 'Recommended_Action'
        ]],
        use_container_width=True
    )
    
    # Download Full Scored File
    st.markdown("<br>", unsafe_allow_html=True)
    full_csv = scored_df.to_csv(index=False)
    
    st.download_button(
        label="📥 Download Full Scored Cohort Report (CSV with Risk Tiers & Actions)",
        data=full_csv,
        file_name="ApexBank_Scored_Customer_Retention_Report.csv",
        mime="text/csv",
        type="primary",
        use_container_width=True
    )
else:
    st.info("💡 Please upload a CSV file or click 'Load Sample Batch Directly' above to execute bulk risk scoring.")

