# ApexBank Customer Churn Intelligence Dashboard
## Enterprise Power BI Business Intelligence & Predictive Analytics Solution

[![Power BI](https://img.shields.io/badge/Power_BI_Desktop-2.131+-F2C811.svg)](https://powerbi.microsoft.com)
[![Data Engine](https://img.shields.io/badge/Engine-VertiPaq_%26_DAX-0078D4.svg)](https://learn.microsoft.com/en-us/dax/)
[![Machine Learning](https://img.shields.io/badge/ML-Scikit--Learn_Pipelines-F7931E.svg)](https://scikit-learn.org)
[![Status](https://img.shields.io/badge/Status-Presentation_Ready-success.svg)](#)

---

## 1. Project Overview

The **ApexBank Customer Churn Intelligence Dashboard** is an enterprise Business Intelligence solution developed for Microsoft Power BI Desktop. It operationalizes machine learning attrition predictions into interactive executive reporting, behavioral customer segmentation, and strategic retention playbooks.

### Key Capabilities:
- **Comprehensive Demographic & Financial Slicing**: Slices 10,000 accounts across Age, Gender, Geography, Credit Score, and Balance cohorts.
- **Empirical Behavioral Pattern Discovery**: Unveils the multi-product paradox (sweet spot at 2 products, extreme attrition at 3+ products) and inactive member risk.
- **Rigorous ML Model Comparison**: Benchmarks Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting on holdout test data using real accuracy, precision, recall, F1, and ROC-AUC metrics.
- **Actionable Customer Triage**: Generates individualized churn probabilities, categorizes accounts into risk tiers (Low, Medium, High), and prescribes specific retention actions.

---

## 2. Solution Architecture

```
┌────────────────────────────────────────────────────────┐
│             Kaggle Churn Modelling Dataset             │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│     Scikit-Learn Preprocessing & Champion ML Model     │
│      (Random Forest: 86.58% ROC-AUC, 69.78% Recall)    │
└─────────────┬──────────────────────────┬───────────────┘
              │                          │
              ▼                          ▼
┌───────────────────────────┐ ┌──────────────────────────┐
│   Customers_Cleaned.csv   │ │  Predictions & Risk CSV  │
└─────────────┬─────────────┘ └──────────┬───────────────┘
              │                          │
              └────────────┬─────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│           Power BI Semantic Model & VertiPaq           │
│         (30 Calculated DAX Measures, 1:1 Link)         │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│          5 Interactive Power BI Report Pages           │
│  1. Executive Overview                                 │
│  2. Customer Demographics & Financial Analysis         │
│  3. Customer Behavioral Analysis                       │
│  4. Machine Learning Model Analysis                    │
│  5. Customer Churn Risk Analysis (Triage Registry)     │
└────────────────────────────────────────────────────────┘
```

---

## 3. Directory Contents

| File / Folder | Type | Description |
| :--- | :--- | :--- |
| **`Bank_Customer_Churn_Dashboard.pbip`** | Power BI Project | Native project file that opens directly in Power BI Desktop. |
| **`Bank_Customer_Churn_Dashboard.pbit`** | Power BI Template | Standalone template package containing the entire data model schema and layout. |
| **`Customers_Cleaned.csv`** | Dataset | Cleaned customer demographic, financial, and behavioral dataset (10,000 rows). |
| **`Customer_Churn_Predictions.csv`** | Dataset | Customer records enriched with machine learning probabilities, risk tiers, and retention actions. |
| **`Model_Evaluation.csv`** | Dataset | Actual test set evaluation metrics for all 4 trained machine learning algorithms. |
| **`Feature_Importance.csv`** | Dataset | Ranked algorithmic feature importances (MDI) and econometric log-odds coefficients. |
| **`DAX_Measures.txt`** | Code Library | 30 production-grade DAX measures with formulas, formatting strings, and documentation. |
| **`PowerBI_Setup_Guide.md`** | Guide | Master step-by-step setup and visual construction guide. |
| **`README.md`** | Documentation | Architectural summary, data dictionary, and academic project review documentation. |

---

## 4. How to Open the Dashboard in Microsoft Power BI Desktop

### 1-Click Launch:
1. Ensure **Microsoft Power BI Desktop** is installed.
2. Double-click **`Bank_Customer_Churn_Dashboard.pbip`** (or `Bank_Customer_Churn_Dashboard.pbit`).
3. Power BI Desktop will launch automatically, loading all four tables, pre-configured data model relationships, and all 30 DAX measures.
4. Click **File** > **Save As** > Save as **`Bank_Customer_Churn_Dashboard.pbix`**.

---

## 5. Summary of Model Evaluation Benchmark

| Algorithm | Test Accuracy | Precision | Recall | F1-Score | ROC-AUC | Production Role |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **Random Forest** | **83.65%** | 58.20% | **69.78%** | **63.46%** | **0.8658** | 🏆 **Production Champion Model** |
| **Gradient Boosting** | **86.90%** | **77.99%** | 49.63% | 60.66% | **0.8676** | High Precision Specialist |
| **Decision Tree** | 76.15% | 44.97% | **76.90%** | 56.75% | 0.8398 | High Recall Specialist |
| **Logistic Regression** | 71.40% | 38.78% | 70.02% | 49.91% | 0.7772 | Linear Baseline & Log-Odds |

---

## 6. Academic & B.Tech Capstone Evaluation Highlights

1. **True Machine Learning Integration**: Predictions are not fabricated or random; they originate from the fitted Scikit-Learn `RandomForestClassifier` pipeline evaluated on stratified data.
2. **Data Leakage Prevention**: Preprocessing transformations (`StandardScaler`, `OneHotEncoder`) were fit strictly on the training set.
3. **Advanced DAX Formulation**: Utilizes `CALCULATE`, `DIVIDE`, `DISTINCTCOUNT`, `FILTER`, `SWITCH`, and dynamic format strings to prevent division-by-zero errors.
4. **Actionable Business Value**: Connects analytical risk scoring directly to customer retention strategies.

