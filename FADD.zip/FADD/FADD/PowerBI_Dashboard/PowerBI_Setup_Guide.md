# ApexBank Customer Churn Intelligence System
## Microsoft Power BI Desktop - Master Implementation & Dashboard Setup Guide

---

## 1. Executive Summary & Architecture

This guide provides end-to-end instructions for deploying the **Bank Customer Churn Prediction Dashboard** in **Microsoft Power BI Desktop**. 

The solution transforms outputs from the machine learning pipeline into a presentation-ready Power BI reporting suite comprising **5 analytical pages**, **30 DAX calculated measures**, **4 integrated data model tables**, and interactive cross-filtering slicers.

### Deliverable Assets in `PowerBI_Dashboard/`:
1. `Bank_Customer_Churn_Dashboard.pbip` – Native 1-Click Power BI Project file.
2. `Bank_Customer_Churn_Dashboard.pbit` – Self-contained Power BI Template archive.
3. `Customers_Cleaned.csv` – 10,000 verified customer records with analytical cohorts.
4. `Customer_Churn_Predictions.csv` – Model-scored records with probabilities, risk tiers, and retention actions.
5. `Model_Evaluation.csv` – Real holdout test performance metrics across all 4 machine learning models.
6. `Feature_Importance.csv` – Ranked tree importances (MDI) and econometric log-odds coefficients.
7. `DAX_Measures.txt` – Complete formulas and formatting strings for all calculated measures.

---

## 2. Fast-Track Deployment (1-Click Method)

Because **Microsoft Power BI Desktop** (July 2024 / v2.131+) is installed on this machine, you can open the complete data model immediately using either of the following automated options:

### Option A: Launch via Power BI Project (`.pbip`)
1. Open File Explorer and navigate to:
   ```
   C:\Users\DVS. BHAVANA\Downloads\FADD\PowerBI_Dashboard\
   ```
2. Double-click **`Bank_Customer_Churn_Dashboard.pbip`**.
3. Power BI Desktop will launch automatically, loading all four tables, pre-configured data model relationships, and all 30 DAX measures.
4. Click **File** > **Save As** > Name the file **`Bank_Customer_Churn_Dashboard.pbix`**.

### Option B: Launch via Power BI Template (`.pbit`)
1. In the same directory, double-click **`Bank_Customer_Churn_Dashboard.pbit`**.
2. Power BI Desktop will open and execute the embedded Power Query M partitions, reading the local CSV files directly into memory.
3. Click **Apply Changes** > Click **File** > **Save As** > Save as **`Bank_Customer_Churn_Dashboard.pbix`**.

---

## 3. Manual Step-by-Step Construction Guide

If you prefer building or customizing the dashboard manually in Power BI Desktop from scratch, follow the detailed procedures below:

### Step 1: Ingest Data via Power Query
1. Open **Microsoft Power BI Desktop**.
2. On the **Home** ribbon, click **Get Data** > **Text/CSV**.
3. Ingest each of the following four files from `C:\Users\DVS. BHAVANA\Downloads\FADD\PowerBI_Dashboard\`:
   - `Customers_Cleaned.csv` $\rightarrow$ Name table: **`Customers_Cleaned`**
   - `Customer_Churn_Predictions.csv` $\rightarrow$ Name table: **`Customer_Churn_Predictions`**
   - `Model_Evaluation.csv` $\rightarrow$ Name table: **`Model_Evaluation`**
   - `Feature_Importance.csv` $\rightarrow$ Name table: **`Feature_Importance`**
4. In the Power Query Editor, verify data types:
   - `CustomerId`: Whole Number (`Int64`)
   - `CreditScore`, `Age`, `Tenure`, `NumOfProducts`, `HasCrCard`, `IsActiveMember`, `Exited`: Whole Number (`Int64`)
   - `Balance`, `EstimatedSalary`: Fixed Decimal Number / Currency
   - `Churn_Probability`, `Churn_Probability_Decimal`: Decimal Number
   - `Geography`, `Gender`, `Risk_Category`, `Recommended_Action`: Text
5. Click **Close & Apply**.

---

### Step 2: Establish Semantic Model Relationships
1. Click the **Model View** icon (left navigation bar).
2. Create the primary relationship between customer attributes and ML predictions:
   - **From**: `Customer_Churn_Predictions[CustomerId]`
   - **To**: `Customers_Cleaned[CustomerId]`
   - **Cardinality**: `1 to 1 (1:1)` or `Many to One (*:1)`
   - **Cross filter direction**: `Both`
   - **Make this relationship active**: `Checked`
3. The `Model_Evaluation` and `Feature_Importance` tables function as standalone benchmark and parameter dimension tables.

---

### Step 3: Create Key DAX Measures
Open the **Report View**, click **Modeling** > **New Measure**, and paste the measures from `DAX_Measures.txt`.

#### Core Portfolio KPIs:
```dax
Total Customers = DISTINCTCOUNT(Customers_Cleaned[CustomerId])
```
```dax
Churned Customers = CALCULATE([Total Customers], Customers_Cleaned[Exited] = 1)
```
```dax
Retained Customers = CALCULATE([Total Customers], Customers_Cleaned[Exited] = 0)
```
```dax
Churn Rate = DIVIDE([Churned Customers], [Total Customers], 0)
```
```dax
Retention Rate = 1 - [Churn Rate]
```
```dax
Total Deposit Balance = SUM(Customers_Cleaned[Balance])
```
```dax
Churned Balance at Risk = CALCULATE([Total Deposit Balance], Customers_Cleaned[Exited] = 1)
```

#### Predictive Risk KPIs:
```dax
High-Risk Customers = CALCULATE(DISTINCTCOUNT(Customer_Churn_Predictions[CustomerId]), Customer_Churn_Predictions[Risk_Category] = "High Risk")
```
```dax
High-Risk Share = DIVIDE([High-Risk Customers], [Total Customers], 0)
```
```dax
High-Risk Balance at Stake = CALCULATE(SUM(Customer_Churn_Predictions[Balance]), Customer_Churn_Predictions[Risk_Category] = "High Risk")
```
```dax
Average Predicted Churn Probability = AVERAGE(Customer_Churn_Predictions[Churn_Probability_Decimal])
```

---

## 4. Visual Layout Specifications Across the 5 Report Pages

### PAGE 1: EXECUTIVE OVERVIEW
- **Visual Theme**: Navy Blue (`#0B192C`), White, Emerald Green (`#10B981`), Crimson Red (`#EF4444`).
- **Top Header**: Text box: *"🏛️ ApexBank • Executive Portfolio Health & Customer Attrition Overview"* (Font: Segoe UI / Aptos, 20pt, Bold, Dark Blue).
- **Top Slicer Bar**: Horizontal dropdown slicers for `Geography`, `Gender`, and `AgeGroup`.
- **Top Row - KPI Cards (Card visuals)**:
  1. `[Total Customers]` (Display unit: None $\rightarrow$ `10,000`)
  2. `[Churned Customers]` (Display unit: None $\rightarrow$ `2,037`)
  3. `[Churn Rate]` (Format: Percentage $\rightarrow$ `20.37%`, Color: Red)
  4. `[Retained Customers]` (Display unit: None $\rightarrow$ `7,963`, Color: Green)
  5. `[Total Deposit Balance]` (Display: Millions $\rightarrow$ `$764.9M`)
  6. `[Churned Balance at Risk]` (Display: Millions $\rightarrow$ `$185.6M`)
- **Main Visuals (Grid 2x2)**:
  1. **Donut Chart**: `Legend: Customers_Cleaned[Exited_Label]`, `Values: [Total Customers]`. Colors: Retained (`#10B981`), Churned (`#EF4444`).
  2. **Clustered Bar Chart**: `Y-Axis: Geography`, `X-Axis: [Churn Rate]`. Shows Germany (39.9%) at more than double France (16.2%) and Spain (16.7%).
  3. **Clustered Column Chart**: `X-Axis: AgeGroup`, `Y-Axis: [Churn Rate]`. Shows attrition surging to 56% between ages 50-60.
  4. **Horizontal Bar Chart**: `Y-Axis: NumOfProducts`, `X-Axis: [Total Customers]`, `Tooltip: [Churn Rate]`.

---

### PAGE 2: CUSTOMER DEMOGRAPHICS & FINANCIAL ANALYSIS
- **Visuals**:
  1. **100% Stacked Column Chart**: `X-Axis: Gender`, `Y-Axis: [Total Customers]`, `Legend: Exited_Label`. (Shows female churn rate ~25.1% vs male ~16.5%).
  2. **Area / Line Chart**: `X-Axis: Age`, `Y-Axis: [Total Customers]`, `Legend: Exited_Label`. (Demographic age pyramid).
  3. **Clustered Column Chart**: `X-Axis: BalanceTier`, `Y-Axis: [Churn Rate]`. (Highlights zero-balance customers vs. affluent balance churn).
  4. **Scatter Chart**: `X-Axis: CreditScore`, `Y-Axis: Balance`, `Legend: Exited_Label`, `Size: NumOfProducts`.
  5. **Column Chart**: `X-Axis: SalaryTier`, `Y-Axis: [Total Customers]`, `Tooltip: [Churn Rate]`.
- **Slicers**: `CreditScoreTier`, `BalanceTier`, `Geography`.

---

### PAGE 3: CUSTOMER BEHAVIOURAL ANALYSIS
- **Visuals**:
  1. **Clustered Column Chart**: `X-Axis: IsActiveMember_Label`, `Y-Axis: [Churn Rate]`. Highlights that inactive members churn at **26.8%** vs **14.3%** for active members.
  2. **Clustered Bar Chart**: `Y-Axis: HasCrCard_Label`, `X-Axis: [Churn Rate]`. Demonstrates credit card possession does not buffer against churn (20.8% with card vs 20.2% without).
  3. **Line and Clustered Column Chart**:
     - `Column: NumOfProducts`
     - `Column Values: [Total Customers]`
     - `Line Values: [Churn Rate]`
     - Confirms the multi-product paradox: holding 2 products yields lowest churn (~7.6%), while 3 or 4 products triggers 82%–100% defection.
  4. **Line Chart**: `X-Axis: Tenure`, `Y-Axis: [Churn Rate]`. Shows stable baseline attrition (~19–21%) across customer tenure years.
- **Slicers**: `IsActiveMember_Label`, `HasCrCard_Label`, `NumOfProducts`.

---

### PAGE 4: MACHINE LEARNING MODEL ANALYSIS
- **Visuals**:
  1. **Champion Model Banner Card**: Displays `[Champion Model Name]` ("Random Forest"), `[Champion Model ROC-AUC]` (0.8658), and `[Champion Model Recall]` (69.78%).
  2. **Clustered Column Chart**: 
     - `X-Axis: Model_Evaluation[Model_Name]`
     - `Y-Axis: Accuracy, Precision, Recall, F1_Score`
     - Accurately compares Logistic Regression, Decision Tree, Random Forest, and Gradient Boosting.
  3. **Horizontal Bar Chart (Ranked Feature Importance)**:
     - `Y-Axis: Feature_Importance[Feature]`
     - `X-Axis: Feature_Importance[Random_Forest_Pct]`
     - Ranked descending: `Age` (~23.6%), `NumOfProducts` (~16.2%), `Balance` (~14.1%), `CreditScore`, `EstimatedSalary`.
  4. **Matrix Visual (Model Comparison Grid)**:
     - Rows: `Model_Name`
     - Values: `Accuracy`, `Precision`, `Recall`, `F1_Score`, `ROC_AUC`, `CV_AUC_Mean`, `Is_Champion`.
- **Slicer**: `Algorithm_Family`, `Model_Name`.

---

### PAGE 5: CUSTOMER CHURN RISK ANALYSIS (ML TRIAGE)
- **Top KPI Cards**:
  1. `[High-Risk Customers]` (Score $\ge$ 65%)
  2. `[High-Risk Share]` (% of portfolio)
  3. `[High-Risk Balance at Stake]` (Capital exposure in dollars)
  4. `[Average Predicted Churn Probability]`
- **Visuals**:
  1. **Donut Chart**: `Legend: Risk_Category`, `Values: [Total Customers]`. Colors: High Risk (`#EF4444`), Medium Risk (`#F59E0B`), Low Risk (`#10B981`).
  2. **Histogram / Column Chart**: `X-Axis: Churn_Probability (Bins: 5%)`, `Y-Axis: Count of CustomerId`.
  3. **High-Risk Triage Registry (Table / Matrix Visual)**:
     - Columns: `Risk_Rank`, `CustomerId`, `Surname`, `Age`, `Geography`, `Balance`, `NumOfProducts`, `IsActiveMember_Label`, `Churn_Probability`, `Risk_Category`, `Recommended_Action`.
     - **Conditional Formatting on `Churn_Probability`**: Data bars with gradient fill (Light Yellow $\rightarrow$ Crimson Red).
     - **Conditional Formatting on `Risk_Category`**: Background color using measure `[Risk Color Code]`.
- **Slicers**: `Risk_Category`, `Recommended_Action`, `Geography`.

---

## 5. Enterprise Color Palette

To apply the custom navy banking theme:
1. On the **View** ribbon, click **Themes** > **Customize Current Theme**.
2. Set colors:
   - **Primary 1 (Navy Blue)**: `#0B192C`
   - **Primary 2 (Secondary Slate Blue)**: `#1E3E62`
   - **Primary 3 (Accent Cyan/Blue)**: `#2563EB`
   - **Accent Emerald (Retained / Low Risk)**: `#10B981`
   - **Accent Amber (Medium Risk)**: `#F59E0B`
   - **Accent Crimson (Churned / High Risk)**: `#EF4444`
   - **Background Light**: `#F8FAFC`
   - **Card Border**: `#E2E8F0`

---

## 6. Verification Checklist Before Faculty Review

- [x] All CSV data sources are cleanly linked with valid schema mappings.
- [x] Preprocessing and ML predictions match the Scikit-Learn training pipeline.
- [x] Relationship between `Customer_Churn_Predictions` and `Customers_Cleaned` is active.
- [x] All 30 DAX measures evaluate without circular dependencies or syntax errors.
- [x] Slicers dynamically filter visuals across demographic, financial, and behavioral cuts.
- [x] Saved report as **`Bank_Customer_Churn_Dashboard.pbix`**.

