$asm = [System.Reflection.Assembly]::LoadFrom("C:\Program Files\Microsoft Power BI Desktop\bin\Microsoft.PowerBI.AdomdClient.dll")
$types = $asm.GetExportedTypes()
Write-Host "Exported types matching 'Connection':"
$types | Where-Object { $_.Name -match "Connection" } | ForEach-Object { $_.FullName }

Write-Host "`nAll Namespaces in this DLL:"
$types | ForEach-Object { $_.Namespace } | Select-Object -Unique

